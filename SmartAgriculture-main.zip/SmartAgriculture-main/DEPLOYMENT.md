# Deployment Guide - Smart Agriculture Node

## Table of Contents
1. [Prerequisites](#prerequisites)
2. [Development Setup](#development-setup)
3. [Raspberry Pi Deployment](#raspberry-pi-deployment)
4. [Configuration](#configuration)
5. [Running the System](#running-the-system)
6. [Troubleshooting](#troubleshooting)
7. [Updates and Maintenance](#updates-and-maintenance)

---

## Prerequisites

### Hardware Requirements
- **Raspberry Pi 4** (2GB RAM minimum, 4GB recommended)
- **MicroSD Card** (16GB minimum, Class 10)
- **Power Supply** (5V 3A USB-C)
- **Soil Moisture Sensor** (Capacitive or Resistive)
- **DHT11 or DHT22** Temperature/Humidity Sensor
- **5V Relay Module** (1-channel)
- **DC Water Pump** (5V or 12V)
- **Jumper Wires** and **Breadboard**
- **Internet Connection** (WiFi or Ethernet)

### Software Requirements
- **Raspbian OS** (Buster or newer)
- **Python 3.7+**
- **Git**
- **Internet access** (for initial setup)

---

## Development Setup

### On Your Laptop (Windows/Mac/Linux)

#### 1. Clone Repository
```bash
git clone https://github.com/yourusername/smart-agriculture-node.git
cd smart-agriculture-node
```

#### 2. Create Virtual Environment
```bash
# Windows
python -m venv venv
venv\Scripts\activate

# Mac/Linux
python3 -m venv venv
source venv/bin/activate
```

#### 3. Install Dependencies
```bash
pip install -r requirements.txt
```

#### 4. Configure Environment
```bash
# Copy example configuration
cp .env.example .env

# Edit configuration (use any text editor)
# Set SYSTEM_MODE=simulation for laptop testing
nano .env
```

#### 5. Train ML Model (Optional but Recommended)
```bash
python ml_models/train_model.py
```

#### 6. Test in Simulation Mode
```bash
python src/main.py --mode simulation --debug
```

You should see:
- System initialization logs
- Simulated sensor readings
- Decision-making process
- Pump control (simulated)

#### 7. Run in Test Mode
```bash
python src/main.py --mode simulation --test
```

This runs 3 cycles and exits, useful for quick testing.

---

## Raspberry Pi Deployment

### Step 1: Prepare Raspberry Pi

#### Install Raspbian OS
1. Download [Raspberry Pi Imager](https://www.raspberrypi.org/software/)
2. Flash Raspbian OS Lite or Desktop to SD card
3. Enable SSH (create empty file named `ssh` in boot partition)
4. Configure WiFi (create `wpa_supplicant.conf` if needed)
5. Insert SD card and boot Raspberry Pi

#### First Boot Configuration
```bash
# SSH into Pi (default password: raspberry)
ssh pi@raspberrypi.local

# Update system
sudo apt-get update
sudo apt-get upgrade -y

# Change default password
passwd

# Configure Pi (optional: enable I2C, SPI)
sudo raspi-config
```

### Step 2: Install Git and Clone Repository

```bash
# Install Git
sudo apt-get install -y git

# Clone repository
cd ~
git clone https://github.com/yourusername/smart-agriculture-node.git
cd smart-agriculture-node
```

### Step 3: Run Setup Script

```bash
chmod +x setup.sh
./setup.sh
```

This script will:
- Install system dependencies
- Install Python packages
- Create virtual environment
- Create data directories
- Setup GPIO permissions
- Create `.env` file from template

### Step 4: Hardware Connections

#### GPIO Pin Mapping (BCM Numbering)
```
Component              GPIO Pin    Physical Pin
─────────────────────────────────────────────
Soil Moisture Sensor   GPIO 17     Pin 11
DHT11/22 Sensor        GPIO 4      Pin 7
Relay Module           GPIO 27     Pin 13
Status LED (optional)  GPIO 22     Pin 15
Ground                 GND         Pin 6, 9, 14, 20, 25, 30, 34, 39
3.3V Power            3V3         Pin 1, 17
5V Power              5V          Pin 2, 4
```

#### Wiring Diagram
```
Raspberry Pi              Sensors/Actuators
─────────────────────────────────────────────

GPIO 17 (Pin 11) ──────→ Soil Moisture Sensor Signal
GPIO 4 (Pin 7)   ──────→ DHT Sensor Data
GPIO 27 (Pin 13) ──────→ Relay IN
GND (Pin 6)      ──────→ All GND connections
3.3V (Pin 1)     ──────→ DHT VCC
5V (Pin 2)       ──────→ Relay VCC, Pump (via relay)

Relay Connections:
  - VCC: 5V from Pi
  - GND: GND from Pi
  - IN:  GPIO 27 from Pi
  - COM: +12V from power supply
  - NO:  Pump positive terminal
  
Pump:
  - Positive: Relay NO
  - Negative: Power supply GND
```

**⚠️ IMPORTANT SAFETY NOTES:**
- Double-check all connections before powering on
- Use appropriate power supply for pump (don't draw from Pi)
- Ensure relay is rated for pump current
- Use flyback diode across pump for protection

### Step 5: Configure for Hardware Mode

Edit `.env` file:
```bash
nano .env
```

Set these values:
```
SYSTEM_MODE=hardware
OPERATION_MODE=auto
ML_ENABLED=true
CLOUD_ENABLED=false  # Set to true if using cloud
DASHBOARD_ENABLED=true
LOG_LEVEL=INFO
```

Adjust GPIO pins if your wiring is different:
```
GPIO_SOIL_MOISTURE=17
GPIO_DHT_SENSOR=4
GPIO_RELAY_PUMP=27
```

### Step 6: Test Hardware

#### Test Sensors Only
```bash
python3 -c "
from src.hardware.hal import HardwareAbstractionLayer
from src.utils.config import config
import logging

logger = logging.getLogger()
hal = HardwareAbstractionLayer(config, logger)

try:
    reading = hal.read_sensors()
    print(f'Moisture: {reading[\"moisture\"]}%')
    print(f'Temperature: {reading[\"temperature\"]}°C')
    print(f'Humidity: {reading[\"humidity\"]}%')
finally:
    hal.cleanup()
"
```

#### Test Pump Control (CAUTION!)
```bash
python3 -c "
from src.hardware.hal import HardwareAbstractionLayer
from src.utils.config import config
import logging
import time

logger = logging.getLogger()
hal = HardwareAbstractionLayer(config, logger)

try:
    print('Turning pump ON for 2 seconds...')
    hal.set_pump(True)
    time.sleep(2)
    print('Turning pump OFF')
    hal.set_pump(False)
finally:
    hal.cleanup()
"
```

### Step 7: Run System

#### Test Mode (3 cycles then exit)
```bash
sudo python3 src/main.py --mode hardware --test
```

#### Full Autonomous Mode
```bash
sudo python3 src/main.py --mode hardware
```

**Note:** `sudo` is required for GPIO access.

---

## Configuration

### Environment Variables (.env)

Key configuration options:

#### System Mode
```
SYSTEM_MODE=hardware  # or simulation
OPERATION_MODE=auto   # or manual
```

#### Sensor Thresholds
```
CRITICAL_LOW_MOISTURE=20   # Water immediately below this
CRITICAL_HIGH_MOISTURE=80  # Never water above this
OPTIMAL_LOW_MOISTURE=30    # Target range low
OPTIMAL_HIGH_MOISTURE=70   # Target range high
```

#### Control Settings
```
DEFAULT_WATERING_DURATION=60  # seconds
MAX_WATERING_DURATION=120     # safety limit
MIN_WATERING_INTERVAL=300     # min time between watering (seconds)
SENSOR_READ_INTERVAL=5        # how often to read sensors
```

#### ML Settings
```
ML_ENABLED=true
ML_CONFIDENCE_THRESHOLD=0.7  # 0.0 to 1.0
```

#### Safety Settings
```
MAX_ERROR_COUNT=5       # errors before requiring manual intervention
RECOVERY_DELAY=60       # seconds before retry after error
FAIL_SAFE_ENABLED=true
```

### YAML Configuration

For more complex configurations, edit files in `config/` directory:
- `default.yaml` - Default settings
- `simulation.yaml` - Development mode
- `production.yaml` - Production deployment

---

## Running the System

### Command Line Options

```bash
python3 src/main.py [options]
```

Options:
- `--mode {simulation,hardware}` - Override system mode
- `--operation {auto,manual}` - Override operation mode
- `--debug` - Enable debug logging
- `--no-ml` - Disable ML advisory layer
- `--test` - Run test mode (3 cycles then exit)

### Examples

```bash
# Simulation mode with debug logging
python3 src/main.py --mode simulation --debug

# Hardware mode, auto operation
sudo python3 src/main.py --mode hardware --operation auto

# Test mode without ML
sudo python3 src/main.py --mode hardware --test --no-ml
```

### Running as Service (Production)

Create systemd service:

```bash
sudo nano /etc/systemd/system/smart-agriculture.service
```

Content:
```ini
[Unit]
Description=Smart Agriculture Irrigation System
After=network.target

[Service]
Type=simple
User=pi
WorkingDirectory=/home/pi/smart-agriculture-node
ExecStart=/home/pi/smart-agriculture-node/venv/bin/python3 /home/pi/smart-agriculture-node/src/main.py --mode hardware
Restart=on-failure
RestartSec=60
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=multi-user.target
```

Enable and start service:
```bash
sudo systemctl daemon-reload
sudo systemctl enable smart-agriculture.service
sudo systemctl start smart-agriculture.service
```

Check status:
```bash
sudo systemctl status smart-agriculture.service
```

View logs:
```bash
sudo journalctl -u smart-agriculture.service -f
```

---

## Troubleshooting

### Common Issues

#### 1. "GPIO not available" or "RPi.GPIO not found"
```bash
# Install GPIO library
pip install RPi.GPIO

# Add user to GPIO group
sudo usermod -a -G gpio $USER

# Log out and back in
```

#### 2. "Permission denied" accessing GPIO
```bash
# Run with sudo
sudo python3 src/main.py --mode hardware

# Or fix permissions
sudo chmod 666 /dev/gpiomem
```

#### 3. DHT Sensor timeout or invalid readings
- Check wiring connections
- Try different GPIO pin
- Add small delay between reads
- DHT sensors can be finicky - retry logic is built-in

#### 4. Soil moisture sensor always reads 0 or 100
- Check sensor type (digital vs analog)
- If analog, ensure ADC (MCP3008) is connected
- Calibrate sensor (see sensor documentation)

#### 5. Pump doesn't turn on
- Check relay LED (should light up when signal sent)
- Verify pump power supply is connected
- Check relay wiring (COM, NO, NC connections)
- Measure voltage at pump terminals

#### 6. System enters SAFE_MODE repeatedly
- Check logs: `tail -f logs/system.log`
- Sensor issue: Fix sensor connections
- Configuration issue: Adjust thresholds in `.env`

### Log Files

```bash
# System logs
tail -f logs/system.log

# View specific log level
grep ERROR logs/system.log
grep WARNING logs/system.log

# Database
sqlite3 data/sensor_data.db "SELECT * FROM sensor_readings ORDER BY timestamp DESC LIMIT 10;"
```

### Debug Mode

Run with full debug output:
```bash
python3 src/main.py --mode hardware --debug
```

This enables:
- Verbose logging (DEBUG level)
- Detailed sensor readings
- Decision-making process details
- State machine transitions

---

## Updates and Maintenance

### Updating Code

```bash
cd ~/smart-agriculture-node

# Pull latest changes
git pull origin main

# Update dependencies (if changed)
source venv/bin/activate
pip install -r requirements.txt --upgrade

# Restart service
sudo systemctl restart smart-agriculture.service
```

### Database Maintenance

```bash
# Backup database
cp data/sensor_data.db data/sensor_data_backup_$(date +%Y%m%d).db

# View statistics
python3 -c "
from src.data.logger import DataLogger
from src.utils.config import config
import logging

logger = logging.getLogger()
dl = DataLogger(config, logger)
stats = dl.get_statistics()
print(stats)
"

# Clean old data (optional)
sqlite3 data/sensor_data.db "DELETE FROM sensor_readings WHERE timestamp < strftime('%s', 'now', '-30 days');"
```

### Log Rotation

Logs automatically rotate when reaching max size (default 5MB).

To manually clean:
```bash
# Keep only recent logs
find logs/ -name "*.log.*" -mtime +30 -delete
```

### Retrain ML Model

Periodically retrain model with new data:

```bash
# Export data from database
python3 -c "
from src.data.logger import DataLogger
from src.utils.config import config
import logging
import pandas as pd

logger = logging.getLogger()
dl = DataLogger(config, logger)
data = dl.get_recent_readings(count=10000)
df = pd.DataFrame(data)
df.to_csv('ml_models/historical_data.csv', index=False)
print('Data exported to ml_models/historical_data.csv')
"

# Retrain model (modify train_model.py to load this data)
python3 ml_models/train_model.py

# Restart system to use new model
sudo systemctl restart smart-agriculture.service
```

---

## System Monitoring

### Real-Time Dashboard

Access dashboard at: `http://raspberrypi.local:5000` or `http://<pi-ip-address>:5000`

### Remote Access

Setup SSH tunnel for remote monitoring:
```bash
# On your laptop
ssh -L 5000:localhost:5000 pi@raspberrypi.local

# Then access dashboard at
http://localhost:5000
```

### Status Check Script

```bash
#!/bin/bash
# status.sh - Quick system status check

echo "Smart Agriculture System Status"
echo "================================"
echo ""

# Service status
echo "Service Status:"
sudo systemctl status smart-agriculture.service | grep Active
echo ""

# Latest sensor reading
echo "Latest Sensor Reading:"
sqlite3 data/sensor_data.db "SELECT datetime, moisture, temperature, humidity FROM sensor_readings ORDER BY timestamp DESC LIMIT 1;"
echo ""

# Last watering event
echo "Last Watering:"
sqlite3 data/sensor_data.db "SELECT datetime, duration FROM irrigation_events WHERE action=1 ORDER BY timestamp DESC LIMIT 1;"
echo ""

# System state
echo "Current State:"
grep "State:" logs/system.log | tail -n 1
echo ""
```

---

## Production Checklist

Before deploying to production:

- [ ] All hardware connections verified and secure
- [ ] Sensors calibrated and tested
- [ ] Pump tested with actual water
- [ ] Configuration thresholds adjusted for your crop/soil
- [ ] ML model trained with relevant data
- [ ] Backup power solution considered (UPS)
- [ ] Physical security (weatherproof enclosure if outdoors)
- [ ] Remote monitoring setup
- [ ] Alert system configured
- [ ] Backup and recovery plan in place
- [ ] Documentation for maintenance personnel
- [ ] Testing in safe conditions first
- [ ] Manual override accessible

---

## Next Steps

1. Test in simulation mode thoroughly
2. Deploy to Raspberry Pi with sensors only
3. Add pump control when confident
4. Monitor for 24-48 hours in test mode
5. Enable full autonomous operation
6. Setup remote monitoring
7. Plan regular maintenance schedule

For questions or issues, refer to:
- [README.md](README.md) - Project overview
- [ARCHITECTURE.md](ARCHITECTURE.md) - System architecture
- [docs/TROUBLESHOOTING.md](docs/TROUBLESHOOTING.md) - Detailed troubleshooting

---

**⚠️ Safety Reminder:** Always ensure pump is controlled safely. Test thoroughly in a controlled environment before deploying to actual crops.
