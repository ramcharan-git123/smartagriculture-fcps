# Smart Agriculture Node: Intelligent Autonomous Irrigation System

## One-Line Definition
A production-grade autonomous irrigation system using Raspberry Pi, IoT sensors, hybrid machine intelligence (rule-based core + ML advisory), cloud connectivity, and real-time monitoring with fail-safe controls.

## Executive Summary

### What This System Is
This is a **real, working, deployable** intelligent agriculture system that autonomously manages irrigation based on soil moisture, temperature, and humidity. It runs on Raspberry Pi, controls a physical water pump through relay, uses hybrid decision intelligence (rule-based safety core + ML optimization layer), communicates with cloud services, provides real-time dashboard monitoring, and includes comprehensive error handling with fail-safe states.

### What Problems It Solves
1. **Over-irrigation waste** - Intelligent soil monitoring prevents water wastage
2. **Under-irrigation damage** - Autonomous control ensures adequate watering
3. **Manual monitoring burden** - Full automation with remote monitoring
4. **Network unreliability** - Offline-capable operation with cloud sync
5. **Hardware failures** - Fail-safe states and error recovery mechanisms
6. **Deployment complexity** - Git-based workflow for easy updates

### Why This Is Innovative
1. **Hybrid Intelligence Model** - Combines rule-based safety (guaranteed bounds) with ML advisory (optimization)
2. **Layered Architecture** - Hardware abstraction allows simulation-first development
3. **Cloud-Edge Computing** - Offline autonomous operation + cloud intelligence
4. **Fail-Safe Design** - Multiple safety layers prevent system failures
5. **Production-Ready** - Real engineering practices, not just proof-of-concept
6. **Git-Based Deployment** - Professional DevOps workflow on embedded system

### Why This Scores High
- ✅ Real hardware integration (sensors, actuators, Raspberry Pi)
- ✅ Multiple technologies (IoT, Cloud, ML, Embedded Systems)
- ✅ Professional software architecture (layered, modular, scalable)
- ✅ Machine learning component (data-driven optimization)
- ✅ Cloud connectivity and dashboard (remote monitoring)
- ✅ Autonomous operation (intelligent decision-making)
- ✅ Safety engineering (fail-safe states, error recovery)
- ✅ Production deployment (Git workflow, configuration management)
- ✅ Comprehensive documentation (architecture, APIs, deployment)
- ✅ Demo-ready (simulation mode, live hardware demo)

---

## System Architecture

### Physical Architecture
```
┌─────────────────────────────────────────────────────────────┐
│                      Raspberry Pi 4                         │
│  ┌─────────────────────────────────────────────────────┐   │
│  │           Smart Agriculture Application              │   │
│  │  [Sensors] → [Decision Engine] → [Control] → [Pump] │   │
│  └─────────────────────────────────────────────────────┘   │
│          ↓                                     ↑            │
│    [Data Logger]                          [Dashboard]       │
│          ↓                                     ↑            │
└──────────┼─────────────────────────────────────┼───────────┘
           ↓                                     ↑
    ┌──────────────┐                    ┌───────────────┐
    │   Cloud DB   │←──────────────────→│   Dashboard   │
    │ (Firebase/   │                    │   Web UI      │
    │  ThingSpeak) │                    │               │
    └──────────────┘                    └───────────────┘

Hardware Components:
├── Raspberry Pi 4 (2GB+ RAM)
├── Soil Moisture Sensor (Analog/Digital)
├── DHT11/DHT22 Temperature+Humidity Sensor
├── 5V Relay Module (1-channel)
├── DC Water Pump (5V/12V)
└── Power Supply (5V 3A for Pi + Pump)
```

### Digital Architecture (Layered)
```
┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
┃                    APPLICATION LAYER                     ┃
┃  ┌─────────────────────────────────────────────────┐    ┃
┃  │  main.py - System Orchestrator & Entry Point   │    ┃
┃  └─────────────────────────────────────────────────┘    ┃
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛
                           ↓
┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
┃                   CONTROL LAYER                          ┃
┃  ┌──────────────────┐  ┌──────────────────────────┐     ┃
┃  │ Decision Engine  │→ │  Automation Controller   │     ┃
┃  │ (Hybrid Model)   │  │  (State Machine)         │     ┃
┃  └──────────────────┘  └──────────────────────────┘     ┃
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛
          ↓                           ↓
┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
┃                  INTELLIGENCE LAYER                      ┃
┃  ┌─────────────────┐  ┌────────────────────────────┐    ┃
┃  │ Rule Engine     │  │  ML Advisory Layer         │    ┃
┃  │ (Safety Core)   │  │  (Optimization Model)      │    ┃
┃  └─────────────────┘  └────────────────────────────┘    ┃
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛
                           ↓
┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
┃                 ABSTRACTION LAYER                        ┃
┃  ┌────────────────────────────────────────────────┐     ┃
┃  │     Hardware Abstraction Layer (HAL)           │     ┃
┃  │  [Simulation Mode] ←→ [Hardware Mode]          │     ┃
┃  └────────────────────────────────────────────────┘     ┃
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛
                           ↓
┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
┃                    HARDWARE LAYER                        ┃
┃  [Sensors] → [GPIO] → [Relay] → [Pump]                  ┃
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛

Cross-Cutting Layers:
├── Cloud Communication Layer (Async)
├── Data Logging Layer (Persistent)
├── Configuration Layer (Environment-based)
├── Error Handling Layer (Fail-Safe)
└── Monitoring Layer (Dashboard API)
```

### Hybrid Intelligence Architecture
```
┌────────────────────────────────────────────────────────┐
│              HYBRID INTELLIGENCE MODEL                 │
├────────────────────────────────────────────────────────┤
│                                                        │
│  INPUT: [Soil Moisture, Temperature, Humidity, Time]  │
│                         ↓                              │
│  ┌──────────────────────────────────────────────┐    │
│  │         RULE-BASED SAFETY CORE               │    │
│  │  • Hard limits enforcement                   │    │
│  │  • Safety bounds checking                    │    │
│  │  • Fail-safe defaults                        │    │
│  │  • Emergency overrides                       │    │
│  │  OUTPUT: [MUST_WATER, MUST_NOT_WATER, SAFE] │    │
│  └──────────────────────────────────────────────┘    │
│                         ↓                              │
│  ┌──────────────────────────────────────────────┐    │
│  │         ML ADVISORY LAYER                    │    │
│  │  • Optimal watering prediction               │    │
│  │  • Pattern recognition                       │    │
│  │  • Resource optimization                     │    │
│  │  • Weather integration (future)              │    │
│  │  OUTPUT: [RECOMMENDED_ACTION, CONFIDENCE]    │    │
│  └──────────────────────────────────────────────┘    │
│                         ↓                              │
│  ┌──────────────────────────────────────────────┐    │
│  │      DECISION FUSION ENGINE                  │    │
│  │  IF rule_output == MUST_WATER:               │    │
│  │      WATER (safety override)                 │    │
│  │  ELIF rule_output == MUST_NOT_WATER:         │    │
│  │      DO_NOT_WATER (safety override)          │    │
│  │  ELSE:                                       │    │
│  │      USE ml_recommendation (optimization)    │    │
│  └──────────────────────────────────────────────┘    │
│                         ↓                              │
│  OUTPUT: [FINAL_DECISION, REASON, CONFIDENCE]         │
└────────────────────────────────────────────────────────┘

Key Principle: 
"Safety through rules, Optimization through ML"
```

---

## System Pipeline

### End-to-End Data Flow
```
[Sensors] → [HAL Read] → [Data Validation] → [Decision Engine]
    ↓                                               ↓
[Raw Data] → [Logging] → [Cloud Sync]    [Rule Check] → [ML Advisory]
                                                    ↓
                                          [Decision Fusion]
                                                    ↓
                                          [Automation Control]
                                                    ↓
                                          [State Machine]
                                                    ↓
                                    [Pump Control via Relay]
                                                    ↓
                                          [Action Logging]
                                                    ↓
                                          [Cloud + Dashboard]
```

### Execution Pipeline
```
1. BOOT SEQUENCE
   ├── Load configuration (env-based)
   ├── Initialize logging system
   ├── Setup hardware abstraction layer
   ├── Load ML model (if available)
   ├── Connect to cloud (non-blocking)
   └── Enter SAFE_IDLE state

2. MAIN LOOP (every 5 seconds)
   ├── Read sensor data (timeout-protected)
   ├── Validate data quality
   ├── Run decision engine (hybrid intelligence)
   ├── Execute automation logic (state machine)
   ├── Control actuators (pump via relay)
   ├── Log data locally
   ├── Sync to cloud (async, non-blocking)
   └── Update dashboard state

3. ERROR HANDLING (on failure)
   ├── Detect failure type
   ├── Log error details
   ├── Enter fail-safe state (pump OFF)
   ├── Attempt recovery
   └── Resume or enter SAFE_MODE

4. SHUTDOWN SEQUENCE
   ├── Complete current cycle
   ├── Turn off pump (safe state)
   ├── Flush logs to disk
   ├── Upload pending cloud data
   ├── Close connections
   └── Clean exit
```

---

## Folder Structure

```
smart-agriculture-node/
├── README.md                          # This file
├── ARCHITECTURE.md                    # Detailed architecture documentation
├── DEPLOYMENT.md                      # Deployment guide
├── requirements.txt                   # Python dependencies
├── setup.sh                          # Raspberry Pi setup script
├── .env.example                      # Environment configuration template
├── .gitignore                        # Git ignore rules
│
├── src/                              # Main source code
│   ├── __init__.py
│   ├── main.py                       # Application entry point
│   │
│   ├── hardware/                     # Hardware abstraction layer
│   │   ├── __init__.py
│   │   ├── hal.py                    # Hardware abstraction interface
│   │   ├── sensors.py                # Sensor drivers (real hardware)
│   │   ├── actuators.py              # Actuator drivers (relay, pump)
│   │   └── simulator.py              # Simulation mode implementation
│   │
│   ├── intelligence/                 # Decision intelligence layer
│   │   ├── __init__.py
│   │   ├── decision_engine.py        # Main decision logic
│   │   ├── rule_engine.py            # Rule-based safety core
│   │   └── ml_advisor.py             # ML advisory layer
│   │
│   ├── control/                      # Control and automation
│   │   ├── __init__.py
│   │   ├── state_machine.py          # System state machine
│   │   └── automation.py             # Automation controller
│   │
│   ├── cloud/                        # Cloud communication
│   │   ├── __init__.py
│   │   ├── cloud_client.py           # Cloud API client
│   │   └── dashboard_api.py          # Dashboard backend API
│   │
│   ├── data/                         # Data management
│   │   ├── __init__.py
│   │   ├── logger.py                 # Data logging system
│   │   └── storage.py                # Local storage management
│   │
│   └── utils/                        # Utilities
│       ├── __init__.py
│       ├── config.py                 # Configuration management
│       ├── errors.py                 # Custom exceptions
│       └── validators.py             # Data validation
│
├── ml_models/                        # Machine learning models
│   ├── irrigation_model.pkl          # Trained ML model
│   ├── training_data.csv             # Historical training data
│   └── train_model.py                # Model training script
│
├── config/                           # Configuration files
│   ├── default.yaml                  # Default configuration
│   ├── simulation.yaml               # Simulation mode config
│   └── production.yaml               # Production mode config
│
├── logs/                             # Log files directory
│   └── .gitkeep
│
├── data/                             # Local data storage
│   ├── sensor_data.db                # SQLite database
│   └── .gitkeep
│
├── tests/                            # Test suite
│   ├── __init__.py
│   ├── test_sensors.py
│   ├── test_decision_engine.py
│   ├── test_state_machine.py
│   └── test_integration.py
│
├── scripts/                          # Utility scripts
│   ├── install_dependencies.sh       # Dependency installation
│   ├── setup_gpio.sh                 # GPIO permissions setup
│   ├── start_service.sh              # System startup script
│   └── deploy.sh                     # Deployment automation
│
├── dashboard/                        # Dashboard web interface
│   ├── index.html                    # Main dashboard page
│   ├── app.js                        # Dashboard logic
│   └── styles.css                    # Dashboard styling
│
└── docs/                             # Additional documentation
    ├── API.md                        # API documentation
    ├── VIVA_GUIDE.md                 # Viva preparation guide
    └── TROUBLESHOOTING.md            # Common issues and solutions
```

---

## Quick Start

### 1. Clone Repository
```bash
git clone https://github.com/yourusername/smart-agriculture-node.git
cd smart-agriculture-node
```

### 2. Setup on Raspberry Pi
```bash
chmod +x setup.sh
./setup.sh
```

### 3. Configure Environment
```bash
cp .env.example .env
nano .env  # Edit configuration
```

### 4. Run in Simulation Mode (Development)
```bash
python3 src/main.py --mode simulation
```

### 5. Run on Real Hardware (Production)
```bash
sudo python3 src/main.py --mode hardware
```

---

## System States and Modes

### System States (State Machine)
```
BOOT → INITIALIZING → SAFE_IDLE → MONITORING → WATERING → MONITORING
                          ↓            ↓            ↓
                      SAFE_MODE ← ERROR_STATE → RECOVERY
                          ↓                         ↓
                      SHUTDOWN ←──────────────────┘
```

### Operation Modes
- **AUTO**: Fully autonomous operation (default)
- **MANUAL**: Manual pump control via dashboard
- **SIMULATION**: Software-only testing (no hardware)
- **HARDWARE**: Real sensor/actuator mode
- **SAFE_MODE**: Emergency state (pump OFF, monitoring only)

---

## Fail-Safe Mechanisms

### Safety Layers
1. **Rule-Based Hard Limits** - Cannot be overridden by ML
2. **Pump Timeout Protection** - Max watering duration limit
3. **Sensor Validation** - Reject invalid/outlier readings
4. **Network Fallback** - Continue offline if cloud unavailable
5. **Power Recovery** - Resume safely after power loss
6. **Error State Handling** - Automatic fail-safe entry

### Default Safe State
```
When ANY error occurs:
├── Pump: OFF (relay open)
├── State: SAFE_MODE
├── Logging: Continue
└── Recovery: Auto-attempt every 60s
```

---

## Technology Stack

### Embedded System
- **Platform**: Raspberry Pi 4 (Raspbian OS)
- **Language**: Python 3.9+
- **GPIO**: RPi.GPIO / gpiozero
- **Sensors**: Adafruit DHT, analog/digital soil sensor

### Intelligence
- **ML Framework**: scikit-learn
- **Model**: Random Forest / Decision Tree
- **Features**: soil_moisture, temp, humidity, time_of_day
- **Target**: optimal_watering_decision

### Cloud & Data
- **Cloud Platform**: Firebase / ThingSpeak / AWS IoT
- **Local Storage**: SQLite
- **Data Format**: JSON / CSV
- **Logging**: Python logging module

### Dashboard
- **Backend**: Flask (lightweight API)
- **Frontend**: HTML5 + JavaScript
- **Charts**: Chart.js
- **Real-time**: Polling / WebSocket (optional)

### DevOps
- **Version Control**: Git + GitHub
- **Configuration**: YAML + .env
- **Deployment**: Shell scripts
- **Testing**: pytest

---

## Key Features

### ✅ Hybrid Intelligence
- Rule-based safety ensures system never enters unsafe state
- ML advisory optimizes water usage and timing
- Decision fusion balances safety and efficiency

### ✅ Hardware Abstraction
- Same codebase runs in simulation and hardware modes
- Easy development on laptop, deploy to Pi
- No hardware required for initial testing

### ✅ Cloud Integration
- Async cloud sync (non-blocking)
- Offline-capable operation
- Remote monitoring via dashboard
- Historical data analysis

### ✅ Production-Ready
- Comprehensive error handling
- Fail-safe state machine
- Logging and debugging
- Configuration management
- Restart recovery

### ✅ Autonomous Operation
- Self-contained decision-making
- 24/7 operation capability
- No manual intervention required
- Intelligent scheduling

---

## Academic Justification

### ML Integration Justification
**Q: Why use ML when rules can work?**

A: The system uses a **hybrid model** where:
- **Rules** handle safety boundaries (critical constraints)
- **ML** optimizes within safe bounds (efficiency improvement)

Example: Rules say "don't water if moisture > 80%", but ML learns "optimal watering time is 6 AM when evaporation is low" or "water for 45 seconds instead of 60 seconds based on weather patterns".

This demonstrates understanding that ML should augment, not replace, safety-critical logic.

### Cloud Justification
**Q: Why cloud when local control works?**

A:
1. **Remote Monitoring** - Check system status from anywhere
2. **Historical Analysis** - Long-term data for ML model training
3. **Multi-Node Scaling** - Manage multiple farms centrally
4. **Alerts & Notifications** - Notify farmer of issues
5. **Data Backup** - Prevent data loss from Pi failure

### Architecture Justification
**Q: Why this layered architecture?**

A:
1. **Separation of Concerns** - Each layer has single responsibility
2. **Testability** - Can test layers independently
3. **Maintainability** - Easy to modify without breaking system
4. **Scalability** - Add features without rewriting core
5. **Industry Standard** - Professional software engineering practice

---

## Viva Preparation

### Key Talking Points

**System Overview**:
"This is an autonomous irrigation system using Raspberry Pi that reads soil moisture, temperature, and humidity sensors, makes intelligent watering decisions using hybrid intelligence (rule-based safety + ML optimization), controls a pump via relay, and syncs data to cloud for remote monitoring."

**Innovation**:
"The innovation is in the hybrid intelligence model - we don't blindly trust ML for safety-critical decisions. Instead, rules enforce hard constraints while ML optimizes within those bounds. This is how real industrial systems work."

**Architecture**:
"We use a layered architecture with hardware abstraction, allowing simulation-first development. The decision engine combines rule-based safety core with ML advisory layer. The state machine ensures system always knows its state and transitions safely."

**Deployment**:
"The system uses Git-based deployment - develop on laptop, push to GitHub, pull on Raspberry Pi. Configuration is environment-based using .env files. The system auto-detects simulation vs hardware mode."

**Fail-Safe**:
"Multiple safety layers: rule-based hard limits, pump timeout, sensor validation, network fallback, power recovery. Default safe state is pump OFF. Any error triggers automatic fail-safe entry."

---

## Demo Script

### Simulation Demo (5 minutes)
```bash
# 1. Show project structure
ls -la
cat README.md

# 2. Run simulation
python3 src/main.py --mode simulation

# 3. Show logs
tail -f logs/system.log

# 4. Open dashboard
firefox http://localhost:5000
```

### Hardware Demo (5 minutes)
```bash
# 1. Connect hardware
# 2. Run system
sudo python3 src/main.py --mode hardware

# 3. Show sensor readings in real-time
# 4. Trigger irrigation (low moisture)
# 5. Show pump activation
# 6. Show cloud dashboard update
```

---

## Performance Specifications

- **Sensor Read Frequency**: 5 seconds
- **Decision Cycle**: 5 seconds
- **Cloud Sync**: 30 seconds (async)
- **CPU Usage**: < 10% (idle), < 30% (active)
- **Memory Usage**: < 150 MB
- **Boot Time**: < 10 seconds
- **Shutdown Time**: < 5 seconds
- **Recovery Time**: < 60 seconds
- **Uptime Target**: 99.9% (8.76 hours downtime/year)

---

## Future Enhancements

1. **Weather API Integration** - Use forecast for irrigation planning
2. **Multi-Crop Support** - Different rules per crop type
3. **Deep Learning** - LSTM for time-series prediction
4. **Computer Vision** - Camera-based plant health monitoring
5. **Mobile App** - Native iOS/Android dashboard
6. **Multi-Node Network** - Manage multiple field nodes
7. **Solar Power** - Battery + solar panel integration
8. **Advanced Scheduling** - Time-based optimization

---

## License
MIT License - Free for academic and commercial use

## Contributors
Your Name - yourname@university.edu

## Acknowledgments
- Department of Computer Science, [Your University]
- IoT & Embedded Systems Lab
- Smart Agriculture Research Group

---

## Support & Contact

**For Issues**: Open a GitHub issue
**For Questions**: Email yourname@university.edu
**For Documentation**: See `/docs` folder

---

**Last Updated**: January 2026
**Version**: 1.0.0
**Status**: Production Ready ✅
