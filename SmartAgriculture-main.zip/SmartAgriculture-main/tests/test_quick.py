"""
Quick Test Script

Run basic tests to verify system functionality.
"""

import sys
from pathlib import Path

# Add src to path
sys.path.insert(0, str(Path(__file__).parent / 'src'))

from utils.config import config
from hardware.hal import HardwareAbstractionLayer
from intelligence.decision_engine import DecisionEngine
from control.state_machine import StateMachine, SystemState
import logging


def test_configuration():
    """Test configuration loading."""
    print("\n[TEST] Configuration")
    print("-" * 50)
    print(f"✓ System Mode: {config.system_mode}")
    print(f"✓ Operation Mode: {config.operation_mode}")
    print(f"✓ ML Enabled: {config.ml_enabled}")
    print(f"✓ Dashboard Enabled: {config.dashboard_enabled}")
    print(f"✓ Database Path: {config.database_path}")
    return True


def test_hardware_abstraction():
    """Test hardware abstraction layer."""
    print("\n[TEST] Hardware Abstraction Layer")
    print("-" * 50)
    
    logger = logging.getLogger('test')
    logger.setLevel(logging.INFO)
    
    try:
        hal = HardwareAbstractionLayer(config, logger)
        
        # Test sensor reading
        reading = hal.read_sensors()
        print(f"✓ Sensor Reading:")
        print(f"  - Moisture: {reading['moisture']}%")
        print(f"  - Temperature: {reading['temperature']}°C")
        print(f"  - Humidity: {reading['humidity']}%")
        
        # Test pump control
        print(f"✓ Pump Control:")
        print(f"  - Initial state: {hal.get_pump_state()}")
        hal.set_pump(True)
        print(f"  - After ON command: {hal.get_pump_state()}")
        hal.set_pump(False)
        print(f"  - After OFF command: {hal.get_pump_state()}")
        
        hal.cleanup()
        return True
    
    except Exception as e:
        print(f"✗ Error: {e}")
        return False


def test_decision_engine():
    """Test decision engine."""
    print("\n[TEST] Decision Engine")
    print("-" * 50)
    
    logger = logging.getLogger('test')
    logger.setLevel(logging.INFO)
    
    try:
        engine = DecisionEngine(config, logger)
        
        # Test case 1: Low moisture (should water)
        sensor_data = {
            'moisture': 15,
            'temperature': 25,
            'humidity': 60
        }
        decision = engine.decide(sensor_data)
        print(f"✓ Test Case 1 (Low moisture 15%):")
        print(f"  - Decision: {'WATER' if decision['action'] else 'NO WATER'}")
        print(f"  - Reason: {decision['reason']}")
        print(f"  - Source: {decision['source']}")
        assert decision['action'] == True, "Should water at 15% moisture"
        
        # Test case 2: High moisture (should not water)
        sensor_data = {
            'moisture': 85,
            'temperature': 25,
            'humidity': 60
        }
        decision = engine.decide(sensor_data)
        print(f"✓ Test Case 2 (High moisture 85%):")
        print(f"  - Decision: {'WATER' if decision['action'] else 'NO WATER'}")
        print(f"  - Reason: {decision['reason']}")
        print(f"  - Source: {decision['source']}")
        assert decision['action'] == False, "Should not water at 85% moisture"
        
        # Test case 3: Optimal range (ML decides)
        sensor_data = {
            'moisture': 45,
            'temperature': 25,
            'humidity': 60
        }
        decision = engine.decide(sensor_data)
        print(f"✓ Test Case 3 (Optimal moisture 45%):")
        print(f"  - Decision: {'WATER' if decision['action'] else 'NO WATER'}")
        print(f"  - Reason: {decision['reason']}")
        print(f"  - Source: {decision['source']}")
        
        return True
    
    except Exception as e:
        print(f"✗ Error: {e}")
        import traceback
        traceback.print_exc()
        return False


def test_state_machine():
    """Test state machine."""
    print("\n[TEST] State Machine")
    print("-" * 50)
    
    logger = logging.getLogger('test')
    logger.setLevel(logging.INFO)
    
    try:
        sm = StateMachine(config, logger)
        
        print(f"✓ Initial state: {sm.get_state().value}")
        assert sm.is_state(SystemState.BOOT)
        
        sm.transition(SystemState.INITIALIZING, "Test transition")
        print(f"✓ After transition: {sm.get_state().value}")
        assert sm.is_state(SystemState.INITIALIZING)
        
        sm.transition(SystemState.SAFE_IDLE, "Test transition")
        print(f"✓ After transition: {sm.get_state().value}")
        assert sm.is_state(SystemState.SAFE_IDLE)
        
        sm.transition(SystemState.MONITORING, "Test transition")
        print(f"✓ After transition: {sm.get_state().value}")
        assert sm.is_state(SystemState.MONITORING)
        
        # Test invalid transition (should fail gracefully)
        try:
            sm.transition(SystemState.BOOT, "Invalid transition")
            print(f"✗ Should have rejected invalid transition")
            return False
        except Exception:
            print(f"✓ Correctly rejected invalid transition")
        
        return True
    
    except Exception as e:
        print(f"✗ Error: {e}")
        import traceback
        traceback.print_exc()
        return False


def main():
    """Run all tests."""
    print("=" * 50)
    print("Smart Agriculture Node - Quick Tests")
    print("=" * 50)
    
    # Setup logging
    logging.basicConfig(
        level=logging.WARNING,
        format='%(asctime)s - %(levelname)s - %(message)s'
    )
    
    results = []
    
    # Run tests
    results.append(("Configuration", test_configuration()))
    results.append(("Hardware Abstraction", test_hardware_abstraction()))
    results.append(("Decision Engine", test_decision_engine()))
    results.append(("State Machine", test_state_machine()))
    
    # Summary
    print("\n" + "=" * 50)
    print("Test Summary")
    print("=" * 50)
    
    passed = sum(1 for _, result in results if result)
    total = len(results)
    
    for test_name, result in results:
        status = "✓ PASS" if result else "✗ FAIL"
        print(f"{status} - {test_name}")
    
    print("-" * 50)
    print(f"Results: {passed}/{total} tests passed")
    
    if passed == total:
        print("\n🎉 All tests passed!")
        return 0
    else:
        print(f"\n⚠️  {total - passed} test(s) failed")
        return 1


if __name__ == '__main__':
    sys.exit(main())
