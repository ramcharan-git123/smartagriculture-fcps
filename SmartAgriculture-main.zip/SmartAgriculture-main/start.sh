#!/bin/bash

# Quick Start Script for Smart Agriculture Node

echo "======================================"
echo "Smart Agriculture Node - Quick Start"
echo "======================================"
echo ""

# Function to check if command exists
command_exists() {
    command -v "$1" >/dev/null 2>&1
}

# Check Python
if ! command_exists python3; then
    echo "❌ Python 3 not found. Please install Python 3.7 or higher."
    exit 1
fi

echo "✓ Python 3 found: $(python3 --version)"

# Check if in virtual environment
if [ -z "$VIRTUAL_ENV" ]; then
    echo ""
    echo "Virtual environment not activated."
    
    if [ -d "venv" ]; then
        echo "Activating existing virtual environment..."
        source venv/bin/activate
    else
        echo "Creating virtual environment..."
        python3 -m venv venv
        source venv/bin/activate
        echo "Installing dependencies..."
        pip install -r requirements.txt
    fi
fi

# Check .env file
if [ ! -f ".env" ]; then
    echo ""
    echo "Creating .env file from template..."
    cp .env.example .env
    echo "✓ .env file created"
fi

# Create directories
mkdir -p data logs ml_models

# Check if ML model exists
if [ ! -f "ml_models/irrigation_model.pkl" ]; then
    echo ""
    echo "ML model not found. Training model..."
    python3 ml_models/train_model.py
fi

# Ask user what to do
echo ""
echo "======================================"
echo "What would you like to do?"
echo "======================================"
echo "1) Run in simulation mode (no hardware needed)"
echo "2) Run quick tests"
echo "3) Train ML model"
echo "4) View logs"
echo "5) Exit"
echo ""
read -p "Enter choice [1-5]: " choice

case $choice in
    1)
        echo ""
        echo "Starting system in simulation mode..."
        echo "Press Ctrl+C to stop"
        echo ""
        python3 src/main.py --mode simulation --debug
        ;;
    2)
        echo ""
        echo "Running quick tests..."
        python3 tests/test_quick.py
        ;;
    3)
        echo ""
        echo "Training ML model..."
        python3 ml_models/train_model.py
        ;;
    4)
        echo ""
        if [ -f "logs/system.log" ]; then
            tail -n 50 logs/system.log
        else
            echo "No logs found yet."
        fi
        ;;
    5)
        echo "Goodbye!"
        exit 0
        ;;
    *)
        echo "Invalid choice."
        exit 1
        ;;
esac
