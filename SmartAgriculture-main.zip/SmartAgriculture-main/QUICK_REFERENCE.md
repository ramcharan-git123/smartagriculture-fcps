# Quick Reference Card

## Most Common Commands

### On Windows (Development)
```powershell
# Setup
python -m venv venv
.\venv\Scripts\Activate.ps1
pip install -r requirements.txt
copy .env.example .env

# Train ML Model
python ml_models\train_model.py

# Run Tests
python tests\test_quick.py

# Run Simulation
python src\main.py --mode simulation
python src\main.py --mode simulation --debug
python src\main.py --mode simulation --test

# View Logs
type logs\system.log
Get-Content logs\system.log -Tail 50
```

### On Raspberry Pi (Production)
```bash
# Initial Setup
git clone <repo-url>
cd smart-agriculture-node
chmod +x setup.sh
./setup.sh

# Run System
sudo python3 src/main.py --mode hardware
sudo python3 src/main.py --mode hardware --test
sudo python3 src/main.py --mode hardware --debug

# As Service
sudo systemctl start smart-agriculture
sudo systemctl stop smart-agriculture
sudo systemctl restart smart-agriculture
sudo systemctl status smart-agriculture
sudo journalctl -u smart-agriculture -f

# View Logs
tail -f logs/system.log
grep ERROR logs/system.log

# Database Queries
sqlite3 data/sensor_data.db "SELECT * FROM sensor_readings ORDER BY timestamp DESC LIMIT 10;"
sqlite3 data/sensor_data.db "SELECT * FROM irrigation_events ORDER BY timestamp DESC LIMIT 10;"
```

## System States
```
BOOT → INITIALIZING → SAFE_IDLE → MONITORING → DECIDING → WATERING → SAFE_IDLE
                                      ↓                                    
                                  SAFE_MODE → RECOVERY
```

## Configuration Quick Edit
```bash
# Edit environment
nano .env

# Key settings
SYSTEM_MODE=simulation  # or hardware
CRITICAL_LOW_MOISTURE=20
CRITICAL_HIGH_MOISTURE=80
ML_ENABLED=true
DASHBOARD_ENABLED=true
```

## GPIO Pin Defaults (BCM)
```
GPIO 17 - Soil Moisture
GPIO 4  - DHT Sensor
GPIO 27 - Relay/Pump
GPIO 22 - Status LED
```

## Dashboard Access
```
http://localhost:5000
http://raspberrypi.local:5000
http://<pi-ip-address>:5000
```

## File Locations
```
Main App:      src/main.py
Config:        .env, config/
Logs:          logs/system.log
Database:      data/sensor_data.db
ML Model:      ml_models/irrigation_model.pkl
Tests:         tests/
Docs:          README.md, ARCHITECTURE.md, DEPLOYMENT.md, docs/
```

## Common Issues

**"Permission denied" on GPIO**
```bash
sudo python3 src/main.py --mode hardware
# or
sudo usermod -a -G gpio $USER
# then logout and login
```

**"Module not found"**
```bash
source venv/bin/activate  # Linux/Mac
.\venv\Scripts\Activate.ps1  # Windows
pip install -r requirements.txt
```

**"Database locked"**
```bash
# Make sure only one instance is running
pkill -f "python.*main.py"
```

**System enters SAFE_MODE**
```bash
# Check logs for reason
tail -50 logs/system.log
# Fix the issue, system will auto-recover
```

## Quick Demo Script

1. Open terminal
2. Navigate to project:
   ```bash
   cd smart-agriculture-node
   ```
3. Activate environment:
   ```bash
   source venv/bin/activate  # or .\venv\Scripts\Activate.ps1
   ```
4. Run simulation with debug:
   ```bash
   python src/main.py --mode simulation --debug
   ```
5. Watch output for ~30 seconds
6. Press Ctrl+C to stop
7. Show logs:
   ```bash
   tail -50 logs/system.log
   ```
8. Show database:
   ```bash
   sqlite3 data/sensor_data.db "SELECT * FROM sensor_readings LIMIT 5;"
   ```

## Architecture Layers (Top to Bottom)
1. **Application** - main.py, orchestration
2. **Cloud** - dashboard API, data sync
3. **Control** - state machine, automation
4. **Intelligence** - rules + ML, decision fusion
5. **Data** - logging, validation, storage
6. **Hardware Abstraction** - simulation/real modes
7. **Hardware** - sensors, actuators, GPIO

## Decision Flow
```
Sensors → Validation → Rule Engine (MUST_WATER/MUST_NOT_WATER/SAFE)
                              ↓
                        If SAFE → ML Advisor → Confidence Check
                                                      ↓
                                          High → Use ML
                                          Low  → Fallback
```

## Safety Mechanisms
1. Critical moisture thresholds (20%, 80%)
2. Maximum watering duration (120s)
3. Minimum watering interval (300s)
4. Sensor validation and outlier detection
5. Automatic pump timeout
6. State machine safe transitions
7. Error recovery with retry limits
8. Fail-safe state (pump always OFF on error)

## Key Features for Viva
- Hybrid intelligence (rules + ML)
- Hardware abstraction (simulation/real)
- Layered architecture (7 layers)
- State machine (9 states)
- Fail-safe design (multiple layers)
- Offline capable (cloud optional)
- Git-based deployment
- Production ready

---

**Print this page for quick reference during demo/viva!**
