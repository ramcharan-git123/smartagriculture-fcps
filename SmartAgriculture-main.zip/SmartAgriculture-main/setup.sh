#!/bin/bash

# Smart Agriculture Node - Setup Script for Raspberry Pi
# This script sets up the environment and installs all dependencies

set -e  # Exit on error

echo "========================================"
echo "Smart Agriculture Node - Setup"
echo "========================================"
echo ""

# Check if running on Raspberry Pi
if [ ! -f /proc/device-tree/model ]; then
    echo "Warning: This doesn't appear to be a Raspberry Pi"
    echo "Continuing anyway..."
fi

# Update system
echo "[1/7] Updating system packages..."
sudo apt-get update
sudo apt-get upgrade -y

# Install Python 3 and pip
echo "[2/7] Installing Python 3 and pip..."
sudo apt-get install -y python3 python3-pip python3-venv

# Install system dependencies
echo "[3/7] Installing system dependencies..."
sudo apt-get install -y \
    git \
    sqlite3 \
    libgpiod2 \
    python3-dev \
    python3-setuptools

# Create virtual environment
echo "[4/7] Creating Python virtual environment..."
if [ ! -d "venv" ]; then
    python3 -m venv venv
fi

# Activate virtual environment
source venv/bin/activate

# Upgrade pip
echo "[5/7] Upgrading pip..."
pip install --upgrade pip

# Install Python dependencies
echo "[6/7] Installing Python dependencies..."
pip install -r requirements.txt

# Create .env file if it doesn't exist
if [ ! -f ".env" ]; then
    echo "[7/7] Creating .env file from template..."
    cp .env.example .env
    echo "Please edit .env file with your configuration!"
else
    echo "[7/7] .env file already exists, skipping..."
fi

# Create data directories
echo "Creating data directories..."
mkdir -p data logs ml_models

# Create .gitkeep files
touch data/.gitkeep logs/.gitkeep

# Setup GPIO permissions (if on Raspberry Pi)
if [ -f /proc/device-tree/model ]; then
    echo "Setting up GPIO permissions..."
    sudo usermod -a -G gpio $USER || true
    sudo usermod -a -G i2c $USER || true
    sudo usermod -a -G spi $USER || true
fi

echo ""
echo "========================================"
echo "Setup Complete!"
echo "========================================"
echo ""
echo "Next steps:"
echo "1. Edit .env file with your configuration:"
echo "   nano .env"
echo ""
echo "2. To run in simulation mode (no hardware needed):"
echo "   python3 src/main.py --mode simulation"
echo ""
echo "3. To run on real hardware:"
echo "   sudo python3 src/main.py --mode hardware"
echo ""
echo "4. For help:"
echo "   python3 src/main.py --help"
echo ""
echo "Note: If you modified GPIO permissions, please log out and log back in."
echo ""
