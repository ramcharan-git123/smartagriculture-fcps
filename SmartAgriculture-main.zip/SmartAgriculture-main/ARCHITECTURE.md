# System Architecture - Smart Agriculture Node

## Table of Contents
1. [System Overview](#system-overview)
2. [Architecture Layers](#architecture-layers)
3. [Component Design](#component-design)
4. [Data Flow](#data-flow)
5. [Control Flow](#control-flow)
6. [Decision Intelligence](#decision-intelligence)
7. [State Machine](#state-machine)
8. [Error Handling](#error-handling)
9. [Deployment Architecture](#deployment-architecture)

---

## System Overview

### System Context Diagram
```
                     ┌─────────────┐
                     │   Farmer    │
                     │   (User)    │
                     └──────┬──────┘
                            │
                     Dashboard/Mobile
                            │
        ┌───────────────────┼───────────────────┐
        │                   │                   │
   ┌────▼────┐         ┌────▼────┐       ┌─────▼─────┐
   │  Cloud  │◄────────┤   Pi    │───────►  Sensors  │
   │ Backend │         │ System  │       │  (Field)  │
   └─────────┘         └────┬────┘       └───────────┘
                            │
                       ┌────▼────┐
                       │  Pump   │
                       │  Relay  │
                       └─────────┘
```

### Deployment View
```
┌─────────────────────────────────────────────────────────┐
│               Development Machine (Laptop)               │
│  ┌──────────────────────────────────────────────────┐  │
│  │   IDE (VS Code)                                  │  │
│  │   • Write Code                                   │  │
│  │   • Run Simulation                               │  │
│  │   • Test Logic                                   │  │
│  └──────────────────────────────────────────────────┘  │
│                        │ git push                       │
└────────────────────────┼───────────────────────────────┘
                         ▼
              ┌──────────────────────┐
              │   GitHub Repository   │
              │   (Version Control)   │
              └──────────────────────┘
                         │ git pull
                         ▼
┌─────────────────────────────────────────────────────────┐
│               Raspberry Pi (Edge Device)                 │
│  ┌──────────────────────────────────────────────────┐  │
│  │   Smart Agriculture Application                  │  │
│  │   • Read Sensors                                 │  │
│  │   • Make Decisions                               │  │
│  │   • Control Pump                                 │  │
│  │   • Log Data                                     │  │
│  │   • Sync Cloud                                   │  │
│  └──────────────────────────────────────────────────┘  │
│         │                                     │          │
│   ┌─────▼─────┐                       ┌──────▼──────┐  │
│   │  Sensors  │                       │    Relay    │  │
│   │   GPIO    │                       │    GPIO     │  │
│   └───────────┘                       └──────┬──────┘  │
│                                              │          │
└──────────────────────────────────────────────┼─────────┘
                                               │
                                        ┌──────▼──────┐
                                        │  Water Pump │
                                        └─────────────┘
```

---

## Architecture Layers

### Layer 1: Hardware Layer
**Responsibility**: Physical interaction with world

```
┌─────────────────────────────────────────────────┐
│              HARDWARE LAYER                     │
├─────────────────────────────────────────────────┤
│                                                 │
│  Input Devices:                                 │
│  ├── Soil Moisture Sensor (Analog/Digital)     │
│  │   • Type: Capacitive/Resistive              │
│  │   • Output: 0-100% moisture                 │
│  │   • GPIO: Analog pin / I2C                  │
│  │                                              │
│  ├── DHT11/DHT22 Sensor                        │
│  │   • Temperature: -40°C to 80°C              │
│  │   • Humidity: 0-100% RH                     │
│  │   • GPIO: Digital pin                       │
│  │                                              │
│  └── Real-Time Clock (Optional)                │
│      • Maintains time during offline           │
│                                                 │
│  Output Devices:                                │
│  └── 5V Relay Module                           │
│      • Controls pump power                     │
│      • GPIO: Digital output pin                │
│      • Safe state: OFF (NO contact)            │
│                                                 │
│  Actuators:                                     │
│  └── DC Water Pump                             │
│      • Voltage: 5V or 12V                      │
│      • Flow rate: 1-3 L/min                    │
│      • Controlled via relay                    │
│                                                 │
└─────────────────────────────────────────────────┘
```

**GPIO Pin Assignment** (Example for Raspberry Pi):
```python
GPIO_PINS = {
    'SOIL_MOISTURE': 17,      # GPIO 17 (or MCP3008 channel)
    'DHT_SENSOR': 4,           # GPIO 4
    'RELAY_PUMP': 27,          # GPIO 27
    'STATUS_LED': 22,          # GPIO 22 (optional)
}
```

### Layer 2: Hardware Abstraction Layer (HAL)
**Responsibility**: Abstract hardware details, enable simulation

```
┌─────────────────────────────────────────────────┐
│         HARDWARE ABSTRACTION LAYER              │
├─────────────────────────────────────────────────┤
│                                                 │
│  Interface: IHardwareProvider                   │
│  ├── read_soil_moisture() -> float             │
│  ├── read_temperature() -> float               │
│  ├── read_humidity() -> float                  │
│  ├── set_pump_state(on: bool) -> None          │
│  └── cleanup() -> None                         │
│                                                 │
│  Implementations:                               │
│  ├── RealHardwareProvider                      │
│  │   └── Uses RPi.GPIO, Adafruit libraries     │
│  │                                              │
│  └── SimulatedHardwareProvider                 │
│      └── Returns synthetic data                │
│                                                 │
│  Mode Detection:                                │
│  • Checks for GPIO availability                │
│  • Falls back to simulation if unavailable     │
│  • Can be forced via --mode flag               │
│                                                 │
└─────────────────────────────────────────────────┘
```

**Key Benefit**: Same application code works in both simulation and hardware mode.

### Layer 3: Data Layer
**Responsibility**: Data management, persistence, validation

```
┌─────────────────────────────────────────────────┐
│                 DATA LAYER                      │
├─────────────────────────────────────────────────┤
│                                                 │
│  Components:                                    │
│  ├── Data Validator                            │
│  │   • Range checking (e.g., 0-100%)          │
│  │   • Outlier detection                       │
│  │   • Timestamp validation                    │
│  │                                              │
│  ├── Local Storage (SQLite)                    │
│  │   • Sensor readings history                 │
│  │   • Action logs                             │
│  │   • System events                           │
│  │   • ML training data                        │
│  │                                              │
│  ├── Data Logger                               │
│  │   • Structured logging                      │
│  │   • Rotating file logs                      │
│  │   • Log levels (DEBUG, INFO, WARN, ERROR)   │
│  │                                              │
│  └── Cache Manager                             │
│      • Recent readings cache                   │
│      • Pending cloud sync queue                │
│                                                 │
│  Data Model:                                    │
│  SensorReading {                                │
│    timestamp: datetime                         │
│    soil_moisture: float                        │
│    temperature: float                          │
│    humidity: float                             │
│    is_valid: bool                              │
│  }                                              │
│                                                 │
│  IrrigationEvent {                             │
│    timestamp: datetime                         │
│    decision: str                               │
│    reason: str                                 │
│    duration: float                             │
│    confidence: float                           │
│  }                                              │
│                                                 │
└─────────────────────────────────────────────────┘
```

### Layer 4: Intelligence Layer
**Responsibility**: Decision-making using hybrid model

```
┌─────────────────────────────────────────────────┐
│              INTELLIGENCE LAYER                 │
├─────────────────────────────────────────────────┤
│                                                 │
│  Rule-Based Safety Core:                        │
│  ├── Hard Constraints                          │
│  │   • MIN_MOISTURE_THRESHOLD = 20%            │
│  │   • MAX_MOISTURE_THRESHOLD = 80%            │
│  │   • MAX_TEMP = 45°C                         │
│  │   • MIN_HUMIDITY = 10%                      │
│  │                                              │
│  ├── Safety Rules                              │
│  │   • MUST_WATER if moisture < 20%            │
│  │   • MUST_NOT_WATER if moisture > 80%        │
│  │   • MUST_NOT_WATER if temp > 45°C (sensor) │
│  │   • MUST_NOT_WATER during rain (future)    │
│  │                                              │
│  └── Output: {MUST_WATER, MUST_NOT_WATER, SAFE}│
│                                                 │
│  ML Advisory Layer:                             │
│  ├── Model Type: Random Forest / Decision Tree │
│  ├── Input Features:                           │
│  │   • soil_moisture                           │
│  │   • temperature                             │
│  │   • humidity                                │
│  │   • time_of_day (hour)                      │
│  │   • day_of_week                             │
│  │   • recent_watering_history                 │
│  │                                              │
│  ├── Output:                                    │
│  │   • recommended_action: bool (water/no)     │
│  │   • confidence: float (0-1)                 │
│  │   • optimal_duration: float (seconds)       │
│  │                                              │
│  └── Training:                                  │
│      • Offline training on historical data     │
│      • Periodic retraining with new data       │
│      • Model versioning                        │
│                                                 │
│  Decision Fusion Engine:                        │
│  ├── Priority: Rules > ML                      │
│  ├── Logic:                                     │
│  │   if rule_output == MUST_WATER:             │
│  │       decision = WATER                      │
│  │       reason = "Safety: Critical low"       │
│  │   elif rule_output == MUST_NOT_WATER:       │
│  │       decision = NO_WATER                   │
│  │       reason = "Safety: Threshold exceeded" │
│  │   elif rule_output == SAFE:                 │
│  │       decision = ml_recommendation          │
│  │       reason = "ML: Optimization"           │
│  │                                              │
│  └── Output: FinalDecision {                   │
│        action: bool                             │
│        reason: str                              │
│        confidence: float                        │
│        source: "RULE" | "ML"                    │
│      }                                          │
│                                                 │
└─────────────────────────────────────────────────┘
```

### Layer 5: Control Layer
**Responsibility**: Automation and state management

```
┌─────────────────────────────────────────────────┐
│               CONTROL LAYER                     │
├─────────────────────────────────────────────────┤
│                                                 │
│  State Machine:                                 │
│  ├── States:                                    │
│  │   • BOOT: System starting                   │
│  │   • INITIALIZING: Loading config, models    │
│  │   • SAFE_IDLE: Ready, pump OFF              │
│  │   • MONITORING: Reading sensors             │
│  │   • DECIDING: Running decision engine       │
│  │   • WATERING: Pump ON, irrigation active    │
│  │   • SAFE_MODE: Error state, pump OFF        │
│  │   • RECOVERY: Attempting recovery           │
│  │   • SHUTDOWN: Graceful shutdown             │
│  │                                              │
│  ├── Transitions:                               │
│  │   • BOOT → INITIALIZING                     │
│  │   • INITIALIZING → SAFE_IDLE (success)      │
│  │   • INITIALIZING → SAFE_MODE (failure)      │
│  │   • SAFE_IDLE → MONITORING                  │
│  │   • MONITORING → DECIDING                   │
│  │   • DECIDING → WATERING | SAFE_IDLE         │
│  │   • WATERING → MONITORING (after duration)  │
│  │   • ANY → SAFE_MODE (on error)              │
│  │   • SAFE_MODE → RECOVERY                    │
│  │   • RECOVERY → SAFE_IDLE | SAFE_MODE        │
│  │                                              │
│  └── Invariants:                                │
│      • Pump ALWAYS OFF except in WATERING      │
│      • Transitions are atomic                  │
│      • State changes are logged                │
│                                                 │
│  Automation Controller:                         │
│  ├── Main Loop (5-second cycle):               │
│  │   1. Read sensors                           │
│  │   2. Validate data                          │
│  │   3. Run decision engine                    │
│  │   4. Update state machine                   │
│  │   5. Execute actions                        │
│  │   6. Log results                            │
│  │                                              │
│  ├── Safety Timers:                            │
│  │   • MAX_WATERING_DURATION = 120 seconds     │
│  │   • MIN_WATERING_INTERVAL = 300 seconds     │
│  │   • SENSOR_READ_TIMEOUT = 5 seconds         │
│  │                                              │
│  └── Mode Management:                           │
│      • AUTO: Fully autonomous                  │
│      • MANUAL: Dashboard control               │
│      • SAFE: Monitoring only, no actions       │
│                                                 │
└─────────────────────────────────────────────────┘
```

### Layer 6: Cloud Communication Layer
**Responsibility**: Remote connectivity, data sync

```
┌─────────────────────────────────────────────────┐
│          CLOUD COMMUNICATION LAYER              │
├─────────────────────────────────────────────────┤
│                                                 │
│  Cloud Client:                                  │
│  ├── Supported Backends:                       │
│  │   • Firebase Realtime DB                    │
│  │   • ThingSpeak IoT Platform                 │
│  │   • AWS IoT Core                            │
│  │   • Custom REST API                         │
│  │                                              │
│  ├── Operations (Async):                       │
│  │   • Push sensor readings                    │
│  │   • Push irrigation events                  │
│  │   • Fetch remote commands                   │
│  │   • Sync system status                      │
│  │                                              │
│  ├── Features:                                  │
│  │   • Non-blocking (threaded)                 │
│  │   • Retry logic with exponential backoff    │
│  │   • Queue for offline data                  │
│  │   • Connection health monitoring            │
│  │                                              │
│  └── Fallback:                                  │
│      • Continue offline if cloud unavailable   │
│      • Queue data locally                      │
│      • Sync when connection restored           │
│                                                 │
│  Dashboard API:                                 │
│  ├── Endpoints:                                 │
│  │   • GET /api/status - System status         │
│  │   • GET /api/sensors - Latest readings      │
│  │   • GET /api/history - Historical data      │
│  │   • POST /api/control - Manual commands     │
│  │                                              │
│  ├── Implementation:                            │
│  │   • Flask lightweight web server            │
│  │   • REST API with JSON                      │
│  │   • CORS enabled for web dashboard          │
│  │                                              │
│  └── Security:                                  │
│      • API key authentication                  │
│      • Rate limiting                           │
│      • Input validation                        │
│                                                 │
└─────────────────────────────────────────────────┘
```

### Layer 7: Application Layer
**Responsibility**: System orchestration

```
┌─────────────────────────────────────────────────┐
│             APPLICATION LAYER                   │
├─────────────────────────────────────────────────┤
│                                                 │
│  main.py - Entry Point                          │
│  ├── Parse command-line arguments              │
│  ├── Load configuration                        │
│  ├── Initialize logging                        │
│  ├── Setup hardware abstraction                │
│  ├── Initialize all subsystems                 │
│  ├── Start main control loop                   │
│  └── Handle shutdown gracefully                │
│                                                 │
│  Configuration Management:                      │
│  ├── Environment-based config (.env)           │
│  ├── YAML config files                         │
│  ├── Command-line overrides                    │
│  └── Default fallbacks                         │
│                                                 │
│  Lifecycle Management:                          │
│  ├── Startup sequence                          │
│  ├── Runtime monitoring                        │
│  ├── Error recovery                            │
│  └── Graceful shutdown                         │
│                                                 │
└─────────────────────────────────────────────────┘
```

---

## Data Flow

### Sensor → Decision → Action Flow
```
┌──────────┐
│ Sensors  │ (Hardware/Simulation)
└────┬─────┘
     │ read_sensors()
     ▼
┌──────────┐
│   HAL    │ (Hardware Abstraction)
└────┬─────┘
     │ SensorReading
     ▼
┌──────────┐
│Validator │ (Data validation)
└────┬─────┘
     │ ValidatedReading
     ▼
┌──────────┐
│Decision  │ (Hybrid Intelligence)
│ Engine   │
└────┬─────┘
     │ Decision + Reason + Confidence
     ▼
┌──────────┐
│ State    │ (State Machine)
│ Machine  │
└────┬─────┘
     │ StateTransition + Action
     ▼
┌──────────┐
│Automation│ (Control execution)
│Controller│
└────┬─────┘
     │ pump_on(duration)
     ▼
┌──────────┐
│   HAL    │ (Hardware Abstraction)
└────┬─────┘
     │ GPIO control
     ▼
┌──────────┐
│  Pump    │ (Physical actuator)
└──────────┘

Parallel Flows:
├── Logger → Local Storage (SQLite)
├── Cloud Client → Remote Database (Firebase/ThingSpeak)
└── Dashboard API → Web UI
```

### Data Lifecycle
```
1. COLLECTION
   Sensor → HAL → Raw Data

2. VALIDATION
   Raw Data → Validator → Validated Data
   • Range check: 0 ≤ moisture ≤ 100
   • Sanity check: -40 ≤ temp ≤ 80
   • Timestamp check: Now ± tolerance

3. STORAGE
   Validated Data → Local DB (immediate)
                 → Cloud DB (async, queued)

4. PROCESSING
   Validated Data → Decision Engine → Decision

5. EXECUTION
   Decision → State Machine → Control Action

6. LOGGING
   Action → Event Log → Storage

7. VISUALIZATION
   Storage → Dashboard API → Web UI
```

---

## Decision Intelligence Details

### Rule Engine Algorithm
```python
def rule_based_decision(moisture, temp, humidity):
    # Safety-critical rules - CANNOT be overridden
    
    # Rule 1: Critical low moisture
    if moisture < CRITICAL_LOW_THRESHOLD (20%):
        return MUST_WATER, "Critical low moisture"
    
    # Rule 2: Too much moisture
    if moisture > CRITICAL_HIGH_THRESHOLD (80%):
        return MUST_NOT_WATER, "Soil saturated"
    
    # Rule 3: Sensor malfunction
    if temp > MAX_SAFE_TEMP (45°C):
        return MUST_NOT_WATER, "Sensor possibly faulty"
    
    # Rule 4: Recent watering (time-based)
    if last_watered_within(MIN_INTERVAL):
        return MUST_NOT_WATER, "Recently watered"
    
    # Rule 5: Safe zone - ML can decide
    if OPTIMAL_LOW (30%) < moisture < OPTIMAL_HIGH (70%):
        return SAFE, "Within optimal range"
    
    # Default: lean towards watering
    return MUST_WATER, "Below optimal"
```

### ML Advisory Algorithm
```python
def ml_advisory_decision(moisture, temp, humidity, time_features):
    # Load trained model
    model = load_model("irrigation_model.pkl")
    
    # Prepare features
    features = [
        moisture,
        temp,
        humidity,
        time_features['hour'],
        time_features['day_of_week'],
        calculate_recent_watering_count(),
    ]
    
    # Predict
    prediction = model.predict([features])[0]  # 0 or 1
    confidence = model.predict_proba([features])[0][prediction]
    
    # Estimate optimal duration based on moisture deficit
    if prediction == 1:  # Water
        deficit = OPTIMAL_MOISTURE - moisture
        duration = min(MAX_DURATION, deficit * DURATION_FACTOR)
    else:
        duration = 0
    
    return {
        'recommendation': bool(prediction),
        'confidence': confidence,
        'duration': duration,
        'features_used': features
    }
```

### Decision Fusion Algorithm
```python
def fused_decision(sensor_data):
    # Step 1: Rule-based safety check
    rule_result, rule_reason = rule_based_decision(
        sensor_data.moisture,
        sensor_data.temperature,
        sensor_data.humidity
    )
    
    # Step 2: If rule is decisive, use it
    if rule_result in [MUST_WATER, MUST_NOT_WATER]:
        return FinalDecision(
            action=(rule_result == MUST_WATER),
            reason=rule_reason,
            confidence=1.0,
            source="RULE_BASED"
        )
    
    # Step 3: Safe zone - consult ML
    ml_result = ml_advisory_decision(
        sensor_data.moisture,
        sensor_data.temperature,
        sensor_data.humidity,
        extract_time_features()
    )
    
    # Step 4: Apply confidence threshold
    if ml_result['confidence'] < ML_CONFIDENCE_THRESHOLD (0.7):
        # Low confidence - use conservative rule
        return FinalDecision(
            action=(sensor_data.moisture < OPTIMAL_MOISTURE),
            reason="ML low confidence, using conservative rule",
            confidence=0.5,
            source="HYBRID_FALLBACK"
        )
    
    # Step 5: Use ML recommendation
    return FinalDecision(
        action=ml_result['recommendation'],
        reason=f"ML optimized (conf: {ml_result['confidence']:.2f})",
        confidence=ml_result['confidence'],
        source="ML_ADVISORY",
        duration=ml_result['duration']
    )
```

---

## State Machine Design

### State Transition Diagram
```
                    ┌─────────┐
                    │  BOOT   │
                    └────┬────┘
                         │
                         ▼
                  ┌──────────────┐
                  │ INITIALIZING │
                  └──┬────────┬──┘
           Success │        │ Failure
                   ▼        ▼
         ┌──────────────┐  ┌───────────┐
         │  SAFE_IDLE   │  │ SAFE_MODE │◄──┐
         └──┬───────────┘  └─────┬─────┘   │
            │                    │          │
            ▼                    │          │
      ┌────────────┐             │          │
      │ MONITORING │             │          │
      └─┬──────────┘             │          │
        │                        │          │
        ▼                        ▼          │
   ┌──────────┐            ┌──────────┐    │
   │ DECIDING │            │ RECOVERY │────┘
   └─┬────────┘            └──────────┘
     │ │
     │ └──────────┐
     │            │
     ▼            ▼
┌──────────┐  ┌──────────┐
│ WATERING │  │SAFE_IDLE │
└─┬────────┘  └──────────┘
  │
  └──→ Back to MONITORING

ANY STATE + Error → SAFE_MODE
```

### State Definitions
```python
class SystemState(Enum):
    BOOT = "boot"                    # System starting
    INITIALIZING = "initializing"    # Loading resources
    SAFE_IDLE = "safe_idle"          # Ready, pump OFF
    MONITORING = "monitoring"        # Reading sensors
    DECIDING = "deciding"            # Running decision logic
    WATERING = "watering"            # Pump ON, irrigating
    SAFE_MODE = "safe_mode"          # Error state, pump OFF
    RECOVERY = "recovery"            # Attempting recovery
    SHUTDOWN = "shutdown"            # Graceful shutdown

class StateMachine:
    def __init__(self):
        self.current_state = SystemState.BOOT
        self.previous_state = None
        self.state_entry_time = time.time()
        self.error_count = 0
    
    def transition(self, new_state, reason=""):
        # Log transition
        logger.info(f"State: {self.current_state} → {new_state} ({reason})")
        
        # Exit current state
        self._exit_state(self.current_state)
        
        # Update state
        self.previous_state = self.current_state
        self.current_state = new_state
        self.state_entry_time = time.time()
        
        # Enter new state
        self._enter_state(new_state)
    
    def _enter_state(self, state):
        if state == SystemState.SAFE_IDLE:
            ensure_pump_off()
        elif state == SystemState.WATERING:
            start_watering_timer()
        elif state == SystemState.SAFE_MODE:
            self.error_count += 1
            ensure_pump_off()
            trigger_alert()
    
    def _exit_state(self, state):
        if state == SystemState.WATERING:
            stop_watering_timer()
```

---

## Error Handling Architecture

### Error Types and Responses
```
┌─────────────────────┬──────────────────────┬─────────────────┐
│   Error Type        │   Detection Method   │   Response      │
├─────────────────────┼──────────────────────┼─────────────────┤
│ Sensor Read Fail    │ Timeout/Exception    │ Retry 3x → SAFE │
│ Invalid Data        │ Validation           │ Discard → Retry │
│ GPIO Error          │ Exception            │ → SAFE_MODE     │
│ Network Fail        │ Connection timeout   │ Continue offline│
│ Pump Timeout        │ Timer exceeded       │ Force OFF       │
│ Config Error        │ Parse error          │ Use defaults    │
│ Storage Error       │ Write exception      │ Log to stderr   │
│ ML Model Error      │ Load/predict fail    │ Use rules only  │
└─────────────────────┴──────────────────────┴─────────────────┘
```

### Error Recovery Flow
```
Error Detected
     │
     ▼
Enter SAFE_MODE (pump OFF)
     │
     ▼
Log error details
     │
     ▼
Increment error counter
     │
     ▼
Wait recovery_delay (60s)
     │
     ▼
Attempt recovery:
├── Re-initialize hardware
├── Clear error flags
├── Test basic operations
│
▼
Recovery success?
├── YES → Return to SAFE_IDLE
└── NO  → Remain in SAFE_MODE
         │
         ▼
    Error count > MAX?
    ├── YES → Require manual restart
    └── NO  → Retry after delay
```

---

## Performance Design

### Resource Management
```
CPU Usage:
├── Idle: < 5% (waiting for sensor reads)
├── Active: 10-20% (decision + control)
└── Peak: < 40% (cloud sync + ML prediction)

Memory Usage:
├── Base: ~50 MB (Python runtime)
├── Application: ~30 MB (code + data structures)
├── ML Model: ~10 MB (loaded in memory)
├── Logs: ~5 MB (rotating, max 10 files)
└── Total: < 150 MB (safe for Pi with 1GB RAM)

Storage:
├── Application code: ~5 MB
├── ML model: ~1 MB
├── Database: 10 MB / month (growing)
├── Logs: 50 MB (rotating, 10 files × 5MB)
└── Total: < 100 MB / month

Network:
├── Sensor upload: ~1 KB / 30 seconds = 2.8 MB / day
├── Command fetch: ~0.5 KB / 60 seconds = 0.7 MB / day
└── Total: < 5 MB / day (< 150 MB / month)
```

### Timing Specifications
```
Sensor Read Cycle: 5 seconds
├── Read sensors: 100-500 ms
├── Validate data: 1-5 ms
├── Decision logic: 5-20 ms
├── State update: 1 ms
├── Control action: 1-10 ms
├── Logging: 1-5 ms
└── Slack: 4+ seconds (buffer)

Watering Cycle: 30-120 seconds
├── Pump activation: immediate
├── Duration: configurable (default 60s)
├── Pump deactivation: immediate
└── Cooldown: 300 seconds (5 minutes)

Cloud Sync: 30 seconds (async)
├── Prepare payload: 1-5 ms
├── HTTP request: 100-1000 ms
├── Retry logic: 3 attempts × 2s timeout
└── Queue if offline: immediate
```

---

## Deployment Architecture

### Git-Based Workflow
```
Developer Laptop                  GitHub                 Raspberry Pi
─────────────────                ────────               ──────────────

1. Write code         git push     2. Repository      git pull    3. Clone repo
   ├── src/          ─────────→      ├── main        ←─────────      ├── setup.sh
   ├── config/                       ├── dev                         ├── Run setup
   └── tests/                        └── release                     └── Run app

4. Test locally                   5. CI/CD (optional)             6. Production
   ├── Simulation                    ├── Linting
   ├── Unit tests                    ├── Tests
   └── Integration                   └── Build

7. Push update       git push     8. Pull update     git pull    9. Restart service
   └── Fix bugs      ─────────→      └── New version ←─────────      └── systemctl restart
```

### Continuous Deployment Process
```bash
# On Raspberry Pi (initial setup)
git clone https://github.com/user/smart-agriculture-node.git
cd smart-agriculture-node
chmod +x setup.sh
./setup.sh

# For updates (can be automated via cron)
cd smart-agriculture-node
git pull origin main
sudo systemctl restart smart-agriculture

# Automatic update script (optional)
# Add to crontab: */30 * * * * /home/pi/smart-agriculture-node/scripts/auto_update.sh
```

---

## Security Considerations

### Authentication & Authorization
- API key for dashboard access
- SSH key for Pi access
- Cloud service credentials in `.env` (not in Git)

### Data Protection
- Local database file permissions (chmod 600)
- Encrypted cloud communication (HTTPS/TLS)
- No sensitive data in logs

### Physical Security
- Pump timeout prevents overflow
- Relay fail-safe state (normally open)
- GPIO cleanup on exit

---

## Summary

This architecture provides:
✅ **Modularity** - Clear separation of concerns
✅ **Scalability** - Easy to add sensors, actuators, or features
✅ **Reliability** - Fail-safe states and error recovery
✅ **Testability** - Simulation mode and unit test interfaces
✅ **Maintainability** - Clean code structure and documentation
✅ **Deployability** - Git-based workflow for updates
✅ **Performance** - Resource-efficient for embedded system
✅ **Safety** - Multiple layers of protection

The system is production-ready, demo-ready, and viva-ready.
