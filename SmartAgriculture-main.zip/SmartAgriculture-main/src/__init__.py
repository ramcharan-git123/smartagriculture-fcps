"""
Smart Agriculture Node - Intelligent Autonomous Irrigation System

A production-grade IoT system for autonomous irrigation using Raspberry Pi,
sensors, hybrid machine intelligence, and cloud connectivity.

Author: Your Name
Version: 1.0.0
"""

__version__ = "1.0.0"
__author__ = "Your Name"
