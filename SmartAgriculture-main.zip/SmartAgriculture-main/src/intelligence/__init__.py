"""Intelligence modules for decision making."""
