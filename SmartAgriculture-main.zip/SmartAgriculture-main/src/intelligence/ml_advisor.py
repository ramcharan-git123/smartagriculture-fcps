"""
ML Advisory Layer

Provides machine learning-based recommendations for irrigation optimization.
This layer advises but does not override safety rules.
"""

import os
from typing import Dict, Optional, Tuple
import time
from datetime import datetime
from src.utils.errors import MLModelError


class MLAdvisor:
    """Machine learning advisory system for irrigation optimization."""
    
    def __init__(self, config, logger):
        """
        Initialize ML advisor.
        
        Args:
            config: Configuration object
            logger: Logger instance
        """
        self.config = config
        self.logger = logger
        self.model = None
        self.model_loaded = False
        self.enabled = config.ml_enabled
        
        if self.enabled:
            self._load_model()
    
    def _load_model(self):
        """Load trained ML model from file."""
        if not self.enabled:
            return
        
        model_path = self.config.ml_model_path
        
        if not os.path.exists(model_path):
            self.logger.warning(f"MLAdvisor: Model file not found: {model_path}")
            self.logger.warning("MLAdvisor: Running without ML optimization")
            self.enabled = False
            return
        
        try:
            import joblib
            self.model = joblib.load(model_path)
            self.model_loaded = True
            self.logger.info(f"MLAdvisor: Model loaded from {model_path}")
        
        except ImportError:
            self.logger.error("MLAdvisor: joblib not available. Install with: pip install joblib")
            self.enabled = False
        
        except Exception as e:
            self.logger.error(f"MLAdvisor: Failed to load model: {e}")
            self.enabled = False
    
    def get_recommendation(self, moisture: float, temperature: float, 
                          humidity: float) -> Dict:
        """
        Get ML-based irrigation recommendation.
        
        Args:
            moisture: Soil moisture percentage (0-100)
            temperature: Temperature in Celsius
            humidity: Humidity percentage (0-100)
            
        Returns:
            Dictionary with:
                - should_water: bool
                - confidence: float (0-1)
                - duration: int (seconds)
                - reason: str
        """
        # If ML is disabled or model not loaded, use fallback logic
        if not self.enabled or not self.model_loaded:
            return self._fallback_recommendation(moisture, temperature, humidity)
        
        try:
            # Prepare features
            features = self._prepare_features(moisture, temperature, humidity)
            
            # Get prediction
            prediction = self.model.predict([features])[0]
            
            # Get confidence (probability)
            try:
                probabilities = self.model.predict_proba([features])[0]
                confidence = probabilities[int(prediction)]
            except AttributeError:
                # Model doesn't support predict_proba
                confidence = 0.8  # Default confidence
            
            # Calculate recommended duration based on moisture deficit
            duration = self._calculate_duration(moisture) if prediction == 1 else 0
            
            should_water = bool(prediction)
            reason = f"ML recommendation (confidence: {confidence:.2f})"
            
            self.logger.debug(f"MLAdvisor: {reason}, water={should_water}, duration={duration}s")
            
            return {
                'should_water': should_water,
                'confidence': confidence,
                'duration': duration,
                'reason': reason
            }
        
        except Exception as e:
            self.logger.error(f"MLAdvisor: Prediction error: {e}")
            raise MLModelError(f"ML prediction failed: {e}")
    
    def _prepare_features(self, moisture: float, temperature: float, 
                         humidity: float) -> list:
        """
        Prepare feature vector for ML model.
        
        Args:
            moisture: Soil moisture percentage
            temperature: Temperature in Celsius
            humidity: Humidity percentage
            
        Returns:
            List of features
        """
        now = datetime.now()
        
        features = [
            moisture,
            temperature,
            humidity,
            now.hour,                    # Hour of day (0-23)
            now.weekday(),               # Day of week (0-6)
            self._get_recent_watering_count()  # Recent watering history
        ]
        
        return features
    
    def _get_recent_watering_count(self) -> int:
        """
        Get count of recent watering events (last 24 hours).
        
        Note: This is a placeholder. In production, query from database.
        
        Returns:
            Number of recent watering events
        """
        # TODO: Implement database query
        # For now, return a default value
        return 0
    
    def _calculate_duration(self, moisture: float) -> int:
        """
        Calculate recommended watering duration based on moisture deficit.
        
        Args:
            moisture: Current soil moisture percentage
            
        Returns:
            Recommended duration in seconds
        """
        optimal_moisture = (self.config.optimal_low_moisture + 
                           self.config.optimal_high_moisture) / 2
        
        deficit = optimal_moisture - moisture
        
        if deficit <= 0:
            return 0
        
        # Linear scaling: 1% deficit = 2 seconds watering
        # Adjust this factor based on your pump flow rate and soil type
        duration_factor = 2.0
        duration = int(deficit * duration_factor)
        
        # Clamp to configured limits
        duration = max(10, min(self.config.max_watering_duration, duration))
        
        return duration
    
    def _fallback_recommendation(self, moisture: float, temperature: float,
                                 humidity: float) -> Dict:
        """
        Fallback recommendation when ML is unavailable.
        
        Uses simple heuristic-based logic.
        
        Args:
            moisture: Soil moisture percentage
            temperature: Temperature in Celsius
            humidity: Humidity percentage
            
        Returns:
            Recommendation dictionary
        """
        optimal_moisture = (self.config.optimal_low_moisture + 
                           self.config.optimal_high_moisture) / 2
        
        # Simple heuristic: water if below optimal
        should_water = moisture < optimal_moisture
        
        # Lower confidence for fallback
        confidence = 0.6
        
        # Calculate duration
        duration = self._calculate_duration(moisture) if should_water else 0
        
        reason = "Heuristic-based (ML unavailable)"
        
        self.logger.debug(f"MLAdvisor: {reason}, water={should_water}")
        
        return {
            'should_water': should_water,
            'confidence': confidence,
            'duration': duration,
            'reason': reason
        }
    
    def is_enabled(self) -> bool:
        """Check if ML advisor is enabled and operational."""
        return self.enabled and self.model_loaded
    
    def get_model_info(self) -> Dict:
        """
        Get information about the loaded model.
        
        Returns:
            Dictionary with model information
        """
        if not self.model_loaded:
            return {'loaded': False}
        
        info = {
            'loaded': True,
            'path': self.config.ml_model_path,
            'type': type(self.model).__name__
        }
        
        try:
            # Try to get model-specific info
            if hasattr(self.model, 'n_estimators'):
                info['n_estimators'] = self.model.n_estimators
            if hasattr(self.model, 'max_depth'):
                info['max_depth'] = self.model.max_depth
        except Exception:
            pass
        
        return info
