"""
Decision Engine - Hybrid Intelligence

Combines rule-based safety core with ML advisory layer to make
final irrigation decisions.
"""

from typing import Dict
from src.intelligence.rule_engine import RuleEngine, RuleDecision
from src.intelligence.ml_advisor import MLAdvisor


class DecisionEngine:
    """
    Hybrid decision engine that fuses rule-based and ML recommendations.
    
    Decision Priority:
    1. Safety rules (MUST_WATER or MUST_NOT_WATER) - Cannot be overridden
    2. ML advisory (when rules return SAFE) - Optimization layer
    3. Fallback heuristics - When ML unavailable or low confidence
    """
    
    def __init__(self, config, logger):
        """
        Initialize decision engine.
        
        Args:
            config: Configuration object
            logger: Logger instance
        """
        self.config = config
        self.logger = logger
        
        # Initialize sub-components
        self.rule_engine = RuleEngine(config, logger)
        self.ml_advisor = MLAdvisor(config, logger)
        
        self.logger.info("DecisionEngine: Initialized hybrid intelligence system")
        self.logger.info(f"DecisionEngine: ML enabled={self.ml_advisor.is_enabled()}")
    
    def decide(self, sensor_data: Dict) -> Dict:
        """
        Make irrigation decision based on sensor data.
        
        Args:
            sensor_data: Dictionary with 'moisture', 'temperature', 'humidity'
            
        Returns:
            Dictionary with:
                - action: bool (True = water, False = don't water)
                - reason: str (explanation)
                - confidence: float (0-1)
                - source: str (RULE_SAFETY, ML_ADVISORY, FALLBACK)
                - duration: int (watering duration in seconds)
        """
        moisture = sensor_data['moisture']
        temperature = sensor_data['temperature']
        humidity = sensor_data['humidity']
        
        self.logger.debug(f"DecisionEngine: Evaluating decision for "
                         f"moisture={moisture}%, temp={temperature}C, humidity={humidity}%")
        
        # Step 1: Evaluate safety rules (highest priority)
        rule_decision, rule_reason = self.rule_engine.evaluate(
            moisture, temperature, humidity
        )
        
        # Step 2: If rule is decisive, use it immediately
        if rule_decision == RuleDecision.MUST_WATER:
            duration = self._calculate_rule_based_duration(moisture)
            decision = {
                'action': True,
                'reason': f"Safety Rule: {rule_reason}",
                'confidence': 1.0,
                'source': 'RULE_SAFETY',
                'duration': duration
            }
            self.logger.info(f"DecisionEngine: MUST_WATER - {rule_reason}")
            return decision
        
        if rule_decision == RuleDecision.MUST_NOT_WATER:
            decision = {
                'action': False,
                'reason': f"Safety Rule: {rule_reason}",
                'confidence': 1.0,
                'source': 'RULE_SAFETY',
                'duration': 0
            }
            self.logger.info(f"DecisionEngine: MUST_NOT_WATER - {rule_reason}")
            return decision
        
        # Step 3: Safe zone - consult ML advisor
        self.logger.debug(f"DecisionEngine: Safe zone - consulting ML advisor")
        
        try:
            ml_recommendation = self.ml_advisor.get_recommendation(
                moisture, temperature, humidity
            )
            
            # Step 4: Check ML confidence threshold
            if ml_recommendation['confidence'] >= self.config.ml_confidence_threshold:
                # High confidence - use ML recommendation
                decision = {
                    'action': ml_recommendation['should_water'],
                    'reason': ml_recommendation['reason'],
                    'confidence': ml_recommendation['confidence'],
                    'source': 'ML_ADVISORY',
                    'duration': ml_recommendation['duration']
                }
                action_str = "WATER" if decision['action'] else "NO_WATER"
                self.logger.info(f"DecisionEngine: ML_ADVISORY - {action_str} "
                               f"(conf: {decision['confidence']:.2f})")
                return decision
            
            else:
                # Low confidence - use conservative fallback
                self.logger.warning(f"DecisionEngine: ML confidence too low "
                                  f"({ml_recommendation['confidence']:.2f} < "
                                  f"{self.config.ml_confidence_threshold})")
                return self._fallback_decision(moisture, temperature, humidity, 
                                               ml_recommendation)
        
        except Exception as e:
            self.logger.error(f"DecisionEngine: ML advisor error: {e}")
            return self._fallback_decision(moisture, temperature, humidity, None)
    
    def _fallback_decision(self, moisture: float, temperature: float, 
                          humidity: float, ml_rec: Dict = None) -> Dict:
        """
        Fallback decision when ML is unavailable or has low confidence.
        
        Uses conservative heuristic-based logic.
        
        Args:
            moisture: Soil moisture percentage
            temperature: Temperature in Celsius
            humidity: Humidity percentage
            ml_rec: ML recommendation (if available)
            
        Returns:
            Decision dictionary
        """
        optimal_moisture = (self.config.optimal_low_moisture + 
                           self.config.optimal_high_moisture) / 2
        
        # Conservative approach: water if below mid-optimal
        should_water = moisture < optimal_moisture
        
        if should_water:
            duration = self._calculate_rule_based_duration(moisture)
            reason = f"Conservative fallback: moisture {moisture}% < optimal {optimal_moisture}%"
        else:
            duration = 0
            reason = f"Conservative fallback: moisture {moisture}% >= optimal {optimal_moisture}%"
        
        if ml_rec:
            reason += f" (ML low confidence: {ml_rec['confidence']:.2f})"
        
        decision = {
            'action': should_water,
            'reason': reason,
            'confidence': 0.5,
            'source': 'FALLBACK',
            'duration': duration
        }
        
        self.logger.info(f"DecisionEngine: FALLBACK - {reason}")
        return decision
    
    def _calculate_rule_based_duration(self, moisture: float) -> int:
        """
        Calculate watering duration using rule-based logic.
        
        Args:
            moisture: Current moisture percentage
            
        Returns:
            Duration in seconds
        """
        optimal_moisture = (self.config.optimal_low_moisture + 
                           self.config.optimal_high_moisture) / 2
        
        deficit = optimal_moisture - moisture
        
        if deficit <= 0:
            return self.config.default_watering_duration // 2
        
        # Scale duration based on deficit
        # More deficit = longer watering
        duration = int(self.config.default_watering_duration * (deficit / 30))
        
        # Clamp to limits
        duration = max(10, min(self.config.max_watering_duration, duration))
        
        return duration
    
    def record_watering(self):
        """Record that watering has occurred (for rule engine)."""
        self.rule_engine.record_watering()
    
    def get_status(self) -> Dict:
        """
        Get decision engine status.
        
        Returns:
            Status dictionary
        """
        return {
            'ml_enabled': self.ml_advisor.is_enabled(),
            'ml_model_info': self.ml_advisor.get_model_info(),
            'time_until_next_watering': self.rule_engine.get_time_until_next_allowed_watering()
        }
