"""
Rule-Based Safety Core

Implements hard safety constraints that cannot be overridden by ML.
Ensures the system always operates within safe bounds.
"""

from enum import Enum
from typing import Tuple
import time


class RuleDecision(Enum):
    """Rule-based decision outcomes."""
    MUST_WATER = "must_water"          # Critical: Must water immediately
    MUST_NOT_WATER = "must_not_water"  # Critical: Must not water
    SAFE = "safe"                       # Safe: ML can decide


class RuleEngine:
    """Rule-based decision engine for safety-critical logic."""
    
    def __init__(self, config, logger):
        """
        Initialize rule engine.
        
        Args:
            config: Configuration object
            logger: Logger instance
        """
        self.config = config
        self.logger = logger
        self.last_watering_time = 0
    
    def evaluate(self, moisture: float, temperature: float, humidity: float) -> Tuple[RuleDecision, str]:
        """
        Evaluate safety rules based on sensor readings.
        
        Args:
            moisture: Soil moisture percentage (0-100)
            temperature: Temperature in Celsius
            humidity: Humidity percentage (0-100)
            
        Returns:
            Tuple of (RuleDecision, reason_string)
        """
        # Rule 1: Critical low moisture - MUST water
        if moisture < self.config.critical_low_moisture:
            reason = f"Critical low moisture: {moisture}% < {self.config.critical_low_moisture}%"
            self.logger.warning(f"RuleEngine: {reason}")
            return RuleDecision.MUST_WATER, reason
        
        # Rule 2: Critical high moisture - MUST NOT water
        if moisture > self.config.critical_high_moisture:
            reason = f"Soil saturated: {moisture}% > {self.config.critical_high_moisture}%"
            self.logger.info(f"RuleEngine: {reason}")
            return RuleDecision.MUST_NOT_WATER, reason
        
        # Rule 3: Extreme temperature - possible sensor fault
        if temperature > self.config.max_safe_temp:
            reason = f"Temperature too high: {temperature}C > {self.config.max_safe_temp}C (possible sensor fault)"
            self.logger.warning(f"RuleEngine: {reason}")
            return RuleDecision.MUST_NOT_WATER, reason
        
        if temperature < self.config.min_safe_temp:
            reason = f"Temperature too low: {temperature}C < {self.config.min_safe_temp}C"
            self.logger.info(f"RuleEngine: {reason}")
            return RuleDecision.MUST_NOT_WATER, reason
        
        # Rule 4: Recently watered - MUST NOT water again too soon
        if self.was_recently_watered():
            time_since = int(time.time() - self.last_watering_time)
            reason = f"Recently watered ({time_since}s ago, min interval: {self.config.min_watering_interval}s)"
            self.logger.info(f"RuleEngine: {reason}")
            return RuleDecision.MUST_NOT_WATER, reason
        
        # Rule 5: Below optimal range - lean towards watering
        if moisture < self.config.optimal_low_moisture:
            reason = f"Below optimal moisture: {moisture}% < {self.config.optimal_low_moisture}%"
            self.logger.info(f"RuleEngine: {reason} (suggesting water)")
            return RuleDecision.MUST_WATER, reason
        
        # Rule 6: Within optimal range - SAFE for ML to decide
        if self.config.optimal_low_moisture <= moisture <= self.config.optimal_high_moisture:
            reason = f"Within optimal range: {self.config.optimal_low_moisture}% <= {moisture}% <= {self.config.optimal_high_moisture}%"
            self.logger.debug(f"RuleEngine: {reason}")
            return RuleDecision.SAFE, reason
        
        # Rule 7: Above optimal but below critical - lean towards not watering
        if moisture > self.config.optimal_high_moisture:
            reason = f"Above optimal moisture: {moisture}% > {self.config.optimal_high_moisture}%"
            self.logger.info(f"RuleEngine: {reason} (suggesting no water)")
            return RuleDecision.MUST_NOT_WATER, reason
        
        # Default: Safe for ML
        return RuleDecision.SAFE, "No critical rule matched"
    
    def was_recently_watered(self) -> bool:
        """
        Check if watering occurred recently.
        
        Returns:
            True if watered within minimum interval
        """
        if self.last_watering_time == 0:
            return False
        
        elapsed = time.time() - self.last_watering_time
        return elapsed < self.config.min_watering_interval
    
    def record_watering(self) -> None:
        """Record that watering has occurred."""
        self.last_watering_time = time.time()
        self.logger.info(f"RuleEngine: Watering recorded at {time.ctime()}")
    
    def reset_watering_timer(self) -> None:
        """Reset the watering timer (for testing/recovery)."""
        self.last_watering_time = 0
        self.logger.info("RuleEngine: Watering timer reset")
    
    def get_time_until_next_allowed_watering(self) -> int:
        """
        Get time (in seconds) until next watering is allowed.
        
        Returns:
            Seconds until next watering allowed, or 0 if can water now
        """
        if self.last_watering_time == 0:
            return 0
        
        elapsed = time.time() - self.last_watering_time
        remaining = self.config.min_watering_interval - elapsed
        return max(0, int(remaining))
