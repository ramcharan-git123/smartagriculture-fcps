"""
Simulated Hardware Provider

Provides simulated sensor readings and actuator control for testing
without physical hardware.
"""

import time
import random
from src.hardware.hal import IHardwareProvider


class SimulatedHardwareProvider(IHardwareProvider):
    """Hardware provider that simulates sensors and actuators."""
    
    def __init__(self, config, logger):
        """
        Initialize simulated hardware.
        
        Args:
            config: Configuration object
            logger: Logger instance
        """
        self.config = config
        self.logger = logger
        
        # Simulation state
        self.moisture = config.sim_initial_moisture
        self.temperature = config.sim_initial_temperature
        self.humidity = config.sim_initial_humidity
        self.pump_on = False
        self.last_update_time = time.time()
        
        # Simulation parameters
        self.moisture_decrease_rate = config.sim_moisture_decrease_rate
        self.moisture_increase_rate = config.sim_moisture_increase_rate
        self.add_noise = config.sim_add_noise
        self.noise_level = config.sim_noise_level
    
    def initialize(self):
        """Initialize simulated hardware."""
        self.logger.info("Simulator: Initialized simulated hardware")
        self.logger.info(f"Simulator: Initial state - Moisture: {self.moisture}%, "
                        f"Temp: {self.temperature}C, Humidity: {self.humidity}%")
    
    def _update_simulation(self):
        """Update simulation state based on time elapsed."""
        current_time = time.time()
        elapsed = current_time - self.last_update_time
        
        if elapsed < 1:  # Update at most once per second
            return
        
        # Update moisture based on pump state
        if self.pump_on:
            # Increase moisture when pump is on
            self.moisture += self.moisture_increase_rate * elapsed
            self.moisture = min(100, self.moisture)
        else:
            # Decrease moisture naturally (evaporation)
            self.moisture -= self.moisture_decrease_rate * elapsed
            self.moisture = max(0, self.moisture)
        
        # Temperature variation (simulated daily cycle)
        # Simple sine wave for day/night temperature change
        hour_of_day = time.localtime().tm_hour
        temp_variation = 5 * (1 + 0.5 * (hour_of_day - 12) / 12)
        self.temperature = self.config.sim_initial_temperature + temp_variation
        
        # Humidity inversely related to temperature (simplified)
        humidity_variation = -2 * temp_variation
        self.humidity = self.config.sim_initial_humidity + humidity_variation
        self.humidity = max(10, min(95, self.humidity))
        
        self.last_update_time = current_time
    
    def _add_noise(self, value: float) -> float:
        """Add random noise to simulated readings."""
        if not self.add_noise:
            return value
        
        noise = random.uniform(-self.noise_level, self.noise_level)
        return value + noise
    
    def read_soil_moisture(self) -> float:
        """
        Read simulated soil moisture.
        
        Returns:
            Moisture percentage (0-100)
        """
        self._update_simulation()
        value = self._add_noise(self.moisture)
        return max(0, min(100, value))
    
    def read_temperature(self) -> float:
        """
        Read simulated temperature.
        
        Returns:
            Temperature in Celsius
        """
        self._update_simulation()
        return self._add_noise(self.temperature)
    
    def read_humidity(self) -> float:
        """
        Read simulated humidity.
        
        Returns:
            Humidity percentage (0-100)
        """
        self._update_simulation()
        value = self._add_noise(self.humidity)
        return max(0, min(100, value))
    
    def set_pump_state(self, state: bool) -> None:
        """
        Set simulated pump state.
        
        Args:
            state: True for ON, False for OFF
        """
        if self.pump_on != state:
            self.pump_on = state
            state_str = "ON" if state else "OFF"
            self.logger.info(f"Simulator: Pump turned {state_str}")
    
    def get_pump_state(self) -> bool:
        """
        Get simulated pump state.
        
        Returns:
            True if pump is ON, False if OFF
        """
        return self.pump_on
    
    def cleanup(self) -> None:
        """Cleanup simulated hardware."""
        self.pump_on = False
        self.logger.info("Simulator: Cleanup completed, pump turned OFF")
