"""Hardware abstraction and sensor/actuator interfaces."""
