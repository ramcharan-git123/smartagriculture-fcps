"""
Real Hardware Provider

Interfaces with actual Raspberry Pi GPIO and sensors.
This module requires RPi.GPIO and Adafruit sensor libraries.
"""

import time
from src.hardware.hal import IHardwareProvider
from src.utils.errors import SensorError, ActuatorError


class RealHardwareProvider(IHardwareProvider):
    """Hardware provider for real Raspberry Pi sensors and actuators."""
    
    def __init__(self, config, logger):
        """
        Initialize real hardware.
        
        Args:
            config: Configuration object
            logger: Logger instance
        """
        self.config = config
        self.logger = logger
        self.pump_on = False
        
        # Import GPIO libraries
        try:
            import RPi.GPIO as GPIO
            self.GPIO = GPIO
        except ImportError:
            logger.error("RPi.GPIO not available. Install with: pip install RPi.GPIO")
            raise
        
        # Import DHT sensor library
        try:
            import adafruit_dht
            import board
            self.adafruit_dht = adafruit_dht
            self.board = board
        except ImportError:
            logger.warning("adafruit_dht not available. Install with: "
                          "pip install adafruit-circuitpython-dht")
            self.adafruit_dht = None
        
        # GPIO pins
        self.pin_soil_moisture = config.gpio_soil_moisture
        self.pin_dht = config.gpio_dht_sensor
        self.pin_relay = config.gpio_relay_pump
        
        self.dht_device = None
    
    def initialize(self):
        """Initialize GPIO and sensors."""
        try:
            # Setup GPIO mode
            self.GPIO.setmode(self.GPIO.BCM)
            self.GPIO.setwarnings(False)
            
            # Setup relay (output)
            self.GPIO.setup(self.pin_relay, self.GPIO.OUT)
            self.GPIO.output(self.pin_relay, self.GPIO.LOW)  # Pump OFF
            
            # Setup soil moisture sensor (input)
            # Note: For analog sensors, you may need MCP3008 ADC
            # This example assumes digital output
            self.GPIO.setup(self.pin_soil_moisture, self.GPIO.IN)
            
            # Setup DHT sensor
            if self.adafruit_dht:
                try:
                    # Map GPIO pin number to board pin
                    board_pin = getattr(self.board, f'D{self.pin_dht}', None)
                    if board_pin:
                        self.dht_device = self.adafruit_dht.DHT22(board_pin)
                        # Or DHT11: self.dht_device = self.adafruit_dht.DHT11(board_pin)
                except Exception as e:
                    self.logger.warning(f"Could not initialize DHT sensor: {e}")
            
            self.logger.info("Real Hardware: GPIO and sensors initialized")
            self.logger.info(f"Real Hardware: Relay pin={self.pin_relay}, "
                           f"Soil pin={self.pin_soil_moisture}, DHT pin={self.pin_dht}")
        
        except Exception as e:
            self.logger.error(f"Real Hardware: Initialization failed: {e}")
            raise
    
    def read_soil_moisture(self) -> float:
        """
        Read soil moisture sensor.
        
        Returns:
            Moisture percentage (0-100)
        
        Note: This is a simplified example. Actual implementation depends on
        sensor type (analog/digital) and may require calibration.
        """
        try:
            # For digital sensors (capacitive)
            digital_value = self.GPIO.input(self.pin_soil_moisture)
            # Convert to percentage (requires calibration)
            moisture = 100 if digital_value == 0 else 0
            
            # For analog sensors with MCP3008 ADC:
            # from adafruit_mcp3xxx.analog_in import AnalogIn
            # channel = AnalogIn(mcp, MCP3008.P0)
            # moisture = (channel.value / 65535) * 100
            
            return moisture
        
        except Exception as e:
            self.logger.error(f"Real Hardware: Error reading soil moisture: {e}")
            raise SensorError(f"Soil moisture read failed: {e}")
    
    def read_temperature(self) -> float:
        """
        Read temperature from DHT sensor.
        
        Returns:
            Temperature in Celsius
        """
        if not self.dht_device:
            raise SensorError("DHT sensor not initialized")
        
        try:
            temperature = self.dht_device.temperature
            if temperature is None:
                raise SensorError("DHT sensor returned None")
            return temperature
        
        except RuntimeError as e:
            # DHT sensors can occasionally fail to read
            self.logger.warning(f"Real Hardware: DHT read error (retry): {e}")
            time.sleep(2)
            try:
                temperature = self.dht_device.temperature
                if temperature is None:
                    raise SensorError("DHT sensor returned None after retry")
                return temperature
            except Exception as e2:
                raise SensorError(f"Temperature read failed: {e2}")
        
        except Exception as e:
            self.logger.error(f"Real Hardware: Error reading temperature: {e}")
            raise SensorError(f"Temperature read failed: {e}")
    
    def read_humidity(self) -> float:
        """
        Read humidity from DHT sensor.
        
        Returns:
            Humidity percentage (0-100)
        """
        if not self.dht_device:
            raise SensorError("DHT sensor not initialized")
        
        try:
            humidity = self.dht_device.humidity
            if humidity is None:
                raise SensorError("DHT sensor returned None")
            return humidity
        
        except RuntimeError as e:
            # DHT sensors can occasionally fail to read
            self.logger.warning(f"Real Hardware: DHT read error (retry): {e}")
            time.sleep(2)
            try:
                humidity = self.dht_device.humidity
                if humidity is None:
                    raise SensorError("DHT sensor returned None after retry")
                return humidity
            except Exception as e2:
                raise SensorError(f"Humidity read failed: {e2}")
        
        except Exception as e:
            self.logger.error(f"Real Hardware: Error reading humidity: {e}")
            raise SensorError(f"Humidity read failed: {e}")
    
    def set_pump_state(self, state: bool) -> None:
        """
        Set pump relay state.
        
        Args:
            state: True for ON, False for OFF
        """
        try:
            # Relay logic: LOW = ON, HIGH = OFF (for active-low relays)
            # Adjust based on your relay module
            gpio_state = self.GPIO.LOW if state else self.GPIO.HIGH
            self.GPIO.output(self.pin_relay, gpio_state)
            self.pump_on = state
            
            state_str = "ON" if state else "OFF"
            self.logger.info(f"Real Hardware: Pump relay set to {state_str}")
        
        except Exception as e:
            self.logger.error(f"Real Hardware: Error setting pump state: {e}")
            raise ActuatorError(f"Pump control failed: {e}")
    
    def get_pump_state(self) -> bool:
        """
        Get current pump state.
        
        Returns:
            True if pump is ON, False if OFF
        """
        return self.pump_on
    
    def cleanup(self) -> None:
        """Cleanup GPIO resources."""
        try:
            # Turn off pump
            self.set_pump_state(False)
            
            # Cleanup DHT sensor
            if self.dht_device:
                self.dht_device.exit()
            
            # Cleanup GPIO
            self.GPIO.cleanup()
            
            self.logger.info("Real Hardware: GPIO cleanup completed")
        
        except Exception as e:
            self.logger.error(f"Real Hardware: Cleanup error: {e}")


# Placeholder for ADC-based analog sensor reading
class MCP3008Reader:
    """
    Helper class for reading analog sensors using MCP3008 ADC.
    
    Example usage:
        adc = MCP3008Reader(channel=0)
        moisture_raw = adc.read()
        moisture_percent = adc.to_percentage(moisture_raw, min_val=0, max_val=65535)
    """
    
    def __init__(self, channel: int, spi_bus=0, spi_device=0):
        """
        Initialize MCP3008 reader.
        
        Args:
            channel: ADC channel (0-7)
            spi_bus: SPI bus number
            spi_device: SPI device number
        """
        try:
            import busio
            import digitalio
            import board
            from adafruit_mcp3xxx.mcp3008 import MCP3008
            from adafruit_mcp3xxx.analog_in import AnalogIn
            
            # Create SPI bus
            spi = busio.SPI(clock=board.SCK, MISO=board.MISO, MOSI=board.MOSI)
            cs = digitalio.DigitalInOut(board.D5)  # Chip select
            
            # Create MCP3008 object
            mcp = MCP3008(spi, cs)
            
            # Create analog input channel
            self.channel = AnalogIn(mcp, channel)
        
        except ImportError:
            raise ImportError("Install with: pip install adafruit-circuitpython-mcp3xxx")
    
    def read(self) -> int:
        """Read raw ADC value."""
        return self.channel.value
    
    def read_voltage(self) -> float:
        """Read voltage."""
        return self.channel.voltage
    
    @staticmethod
    def to_percentage(value: int, min_val: int = 0, max_val: int = 65535) -> float:
        """
        Convert raw ADC value to percentage.
        
        Args:
            value: Raw ADC value
            min_val: Minimum calibration value
            max_val: Maximum calibration value
            
        Returns:
            Percentage (0-100)
        """
        return ((value - min_val) / (max_val - min_val)) * 100
