"""
Hardware Abstraction Layer (HAL)

Provides a unified interface for hardware access, supporting both
simulation mode and real hardware mode.
"""

from abc import ABC, abstractmethod
from typing import Dict, Optional
import time


class IHardwareProvider(ABC):
    """Abstract interface for hardware providers."""
    
    @abstractmethod
    def read_soil_moisture(self) -> float:
        """
        Read soil moisture sensor.
        
        Returns:
            Moisture percentage (0-100)
        """
        pass
    
    @abstractmethod
    def read_temperature(self) -> float:
        """
        Read temperature sensor.
        
        Returns:
            Temperature in Celsius
        """
        pass
    
    @abstractmethod
    def read_humidity(self) -> float:
        """
        Read humidity sensor.
        
        Returns:
            Humidity percentage (0-100)
        """
        pass
    
    @abstractmethod
    def set_pump_state(self, state: bool) -> None:
        """
        Set pump state (ON/OFF).
        
        Args:
            state: True for ON, False for OFF
        """
        pass
    
    @abstractmethod
    def get_pump_state(self) -> bool:
        """
        Get current pump state.
        
        Returns:
            True if pump is ON, False if OFF
        """
        pass
    
    @abstractmethod
    def cleanup(self) -> None:
        """Cleanup hardware resources."""
        pass
    
    @abstractmethod
    def initialize(self) -> None:
        """Initialize hardware."""
        pass


class HardwareAbstractionLayer:
    """
    Hardware Abstraction Layer that selects appropriate provider
    based on system mode.
    """
    
    def __init__(self, config, logger):
        """
        Initialize HAL with configuration.
        
        Args:
            config: Configuration object
            logger: Logger instance
        """
        self.config = config
        self.logger = logger
        self.provider: Optional[IHardwareProvider] = None
        self.last_reading_time = 0
        
        # Select provider based on mode
        self._select_provider()
    
    def _select_provider(self):
        """Select appropriate hardware provider based on mode."""
        mode = self.config.system_mode
        
        if mode == 'simulation':
            from .simulator import SimulatedHardwareProvider
            self.provider = SimulatedHardwareProvider(self.config, self.logger)
            self.logger.info("HAL: Using SimulatedHardwareProvider")
        
        elif mode == 'hardware':
            try:
                from .sensors import RealHardwareProvider
                self.provider = RealHardwareProvider(self.config, self.logger)
                self.logger.info("HAL: Using RealHardwareProvider")
            except ImportError as e:
                self.logger.warning(f"HAL: Cannot load RealHardwareProvider: {e}")
                self.logger.warning("HAL: Falling back to SimulatedHardwareProvider")
                from .simulator import SimulatedHardwareProvider
                self.provider = SimulatedHardwareProvider(self.config, self.logger)
        
        else:
            raise ValueError(f"Unknown system mode: {mode}")
        
        # Initialize the provider
        self.provider.initialize()
    
    def read_sensors(self) -> Dict[str, float]:
        """
        Read all sensors.
        
        Returns:
            Dictionary with 'moisture', 'temperature', 'humidity', 'timestamp'
        """
        current_time = time.time()
        
        try:
            moisture = self.provider.read_soil_moisture()
            temperature = self.provider.read_temperature()
            humidity = self.provider.read_humidity()
            
            self.last_reading_time = current_time
            
            return {
                'moisture': round(moisture, 2),
                'temperature': round(temperature, 2),
                'humidity': round(humidity, 2),
                'timestamp': current_time
            }
        
        except Exception as e:
            self.logger.error(f"HAL: Error reading sensors: {e}")
            raise
    
    def set_pump(self, state: bool) -> None:
        """
        Set pump state.
        
        Args:
            state: True for ON, False for OFF
        """
        try:
            self.provider.set_pump_state(state)
            state_str = "ON" if state else "OFF"
            self.logger.info(f"HAL: Pump set to {state_str}")
        
        except Exception as e:
            self.logger.error(f"HAL: Error setting pump state: {e}")
            raise
    
    def get_pump_state(self) -> bool:
        """
        Get current pump state.
        
        Returns:
            True if pump is ON, False if OFF
        """
        try:
            return self.provider.get_pump_state()
        except Exception as e:
            self.logger.error(f"HAL: Error getting pump state: {e}")
            return False
    
    def cleanup(self):
        """Cleanup hardware resources."""
        if self.provider:
            try:
                self.provider.cleanup()
                self.logger.info("HAL: Cleanup completed")
            except Exception as e:
                self.logger.error(f"HAL: Error during cleanup: {e}")
    
    def __enter__(self):
        """Context manager entry."""
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit."""
        self.cleanup()
