"""
Data Logger

Handles logging of sensor readings, decisions, and system events
to local storage and prepares data for cloud sync.
"""

import sqlite3
import time
from datetime import datetime
from typing import Dict, List, Optional
from pathlib import Path


class DataLogger:
    """Logger for sensor data and system events."""
    
    def __init__(self, config, logger):
        """
        Initialize data logger.
        
        Args:
            config: Configuration object
            logger: Logger instance
        """
        self.config = config
        self.logger = logger
        self.db_path = config.database_path
        
        # Ensure database directory exists
        Path(self.db_path).parent.mkdir(parents=True, exist_ok=True)
        
        # Initialize database
        self._init_database()
    
    def _init_database(self):
        """Initialize SQLite database with required tables."""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Sensor readings table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS sensor_readings (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    timestamp REAL NOT NULL,
                    datetime TEXT NOT NULL,
                    moisture REAL NOT NULL,
                    temperature REAL NOT NULL,
                    humidity REAL NOT NULL,
                    is_valid BOOLEAN DEFAULT 1
                )
            ''')
            
            # Irrigation events table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS irrigation_events (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    timestamp REAL NOT NULL,
                    datetime TEXT NOT NULL,
                    decision TEXT NOT NULL,
                    action BOOLEAN NOT NULL,
                    reason TEXT,
                    confidence REAL,
                    source TEXT,
                    duration INTEGER,
                    moisture REAL,
                    temperature REAL,
                    humidity REAL
                )
            ''')
            
            # System events table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS system_events (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    timestamp REAL NOT NULL,
                    datetime TEXT NOT NULL,
                    event_type TEXT NOT NULL,
                    state TEXT,
                    message TEXT
                )
            ''')
            
            # Create indices for faster queries
            cursor.execute('''
                CREATE INDEX IF NOT EXISTS idx_sensor_timestamp 
                ON sensor_readings(timestamp)
            ''')
            
            cursor.execute('''
                CREATE INDEX IF NOT EXISTS idx_irrigation_timestamp 
                ON irrigation_events(timestamp)
            ''')
            
            conn.commit()
            conn.close()
            
            self.logger.info(f"DataLogger: Database initialized at {self.db_path}")
        
        except Exception as e:
            self.logger.error(f"DataLogger: Database init error: {e}")
            raise
    
    def log_sensor_reading(self, reading: Dict):
        """
        Log sensor reading to database.
        
        Args:
            reading: Dictionary with sensor data
        """
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            cursor.execute('''
                INSERT INTO sensor_readings 
                (timestamp, datetime, moisture, temperature, humidity, is_valid)
                VALUES (?, ?, ?, ?, ?, ?)
            ''', (
                reading.get('timestamp', time.time()),
                datetime.now().isoformat(),
                reading['moisture'],
                reading['temperature'],
                reading['humidity'],
                reading.get('is_valid', True)
            ))
            
            conn.commit()
            conn.close()
            
            self.logger.debug("DataLogger: Sensor reading logged")
        
        except Exception as e:
            self.logger.error(f"DataLogger: Error logging sensor reading: {e}")
    
    def log_irrigation_event(self, decision: Dict, sensor_data: Dict):
        """
        Log irrigation decision and event.
        
        Args:
            decision: Decision dictionary from decision engine
            sensor_data: Sensor reading that led to decision
        """
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            cursor.execute('''
                INSERT INTO irrigation_events
                (timestamp, datetime, decision, action, reason, confidence, 
                 source, duration, moisture, temperature, humidity)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                time.time(),
                datetime.now().isoformat(),
                'WATER' if decision['action'] else 'NO_WATER',
                decision['action'],
                decision['reason'],
                decision['confidence'],
                decision['source'],
                decision['duration'],
                sensor_data['moisture'],
                sensor_data['temperature'],
                sensor_data['humidity']
            ))
            
            conn.commit()
            conn.close()
            
            self.logger.debug("DataLogger: Irrigation event logged")
        
        except Exception as e:
            self.logger.error(f"DataLogger: Error logging irrigation event: {e}")
    
    def log_system_event(self, event_type: str, state: Optional[str] = None, 
                        message: Optional[str] = None):
        """
        Log system event.
        
        Args:
            event_type: Type of event (e.g., 'startup', 'error', 'shutdown')
            state: Current system state
            message: Event message
        """
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            cursor.execute('''
                INSERT INTO system_events
                (timestamp, datetime, event_type, state, message)
                VALUES (?, ?, ?, ?, ?)
            ''', (
                time.time(),
                datetime.now().isoformat(),
                event_type,
                state,
                message
            ))
            
            conn.commit()
            conn.close()
            
            self.logger.debug(f"DataLogger: System event logged: {event_type}")
        
        except Exception as e:
            self.logger.error(f"DataLogger: Error logging system event: {e}")
    
    def get_recent_readings(self, count: int = 100) -> List[Dict]:
        """
        Get recent sensor readings.
        
        Args:
            count: Number of readings to retrieve
            
        Returns:
            List of reading dictionaries
        """
        try:
            conn = sqlite3.connect(self.db_path)
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            
            cursor.execute('''
                SELECT * FROM sensor_readings
                ORDER BY timestamp DESC
                LIMIT ?
            ''', (count,))
            
            rows = cursor.fetchall()
            conn.close()
            
            return [dict(row) for row in rows]
        
        except Exception as e:
            self.logger.error(f"DataLogger: Error getting recent readings: {e}")
            return []
    
    def get_recent_events(self, count: int = 50) -> List[Dict]:
        """
        Get recent irrigation events.
        
        Args:
            count: Number of events to retrieve
            
        Returns:
            List of event dictionaries
        """
        try:
            conn = sqlite3.connect(self.db_path)
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            
            cursor.execute('''
                SELECT * FROM irrigation_events
                ORDER BY timestamp DESC
                LIMIT ?
            ''', (count,))
            
            rows = cursor.fetchall()
            conn.close()
            
            return [dict(row) for row in rows]
        
        except Exception as e:
            self.logger.error(f"DataLogger: Error getting recent events: {e}")
            return []
    
    def get_statistics(self) -> Dict:
        """
        Get statistics from logged data.
        
        Returns:
            Dictionary with statistics
        """
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Total readings
            cursor.execute('SELECT COUNT(*) FROM sensor_readings')
            total_readings = cursor.fetchone()[0]
            
            # Total irrigation events
            cursor.execute('SELECT COUNT(*) FROM irrigation_events WHERE action = 1')
            total_waterings = cursor.fetchone()[0]
            
            # Average moisture
            cursor.execute('SELECT AVG(moisture) FROM sensor_readings WHERE is_valid = 1')
            avg_moisture = cursor.fetchone()[0] or 0
            
            # Last watering time
            cursor.execute('''
                SELECT timestamp FROM irrigation_events 
                WHERE action = 1 
                ORDER BY timestamp DESC 
                LIMIT 1
            ''')
            result = cursor.fetchone()
            last_watering = result[0] if result else None
            
            conn.close()
            
            return {
                'total_readings': total_readings,
                'total_waterings': total_waterings,
                'avg_moisture': round(avg_moisture, 2),
                'last_watering': last_watering
            }
        
        except Exception as e:
            self.logger.error(f"DataLogger: Error getting statistics: {e}")
            return {}
