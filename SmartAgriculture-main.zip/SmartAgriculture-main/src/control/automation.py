"""
Automation Controller

Orchestrates the main control loop, coordinating sensor reading,
decision making, and actuator control.
"""

import time
import threading
from typing import Optional, Dict
from src.control.state_machine import StateMachine, SystemState
from src.intelligence.decision_engine import DecisionEngine
from src.hardware.hal import HardwareAbstractionLayer
from src.utils.validators import DataValidator
from src.utils.errors import HardwareError, DataValidationError


class AutomationController:
    """Main automation controller for the irrigation system."""
    
    def __init__(self, config, logger, hal: HardwareAbstractionLayer,
                 decision_engine: DecisionEngine, state_machine: StateMachine):
        """
        Initialize automation controller.
        
        Args:
            config: Configuration object
            logger: Logger instance
            hal: Hardware abstraction layer
            decision_engine: Decision engine
            state_machine: State machine
        """
        self.config = config
        self.logger = logger
        self.hal = hal
        self.decision_engine = decision_engine
        self.state_machine = state_machine
        self.validator = DataValidator(config)
        
        self.running = False
        self.watering_start_time: Optional[float] = None
        self.watering_duration: int = 0
        self.last_sensor_reading: Optional[Dict] = None
        self.recent_readings = []  # For outlier detection
        self.max_recent_readings = 20
        
        # Timing
        self.cycle_interval = config.sensor_read_interval
        self.last_cycle_time = 0
    
    def start(self):
        """Start the automation loop."""
        if self.running:
            self.logger.warning("AutomationController: Already running")
            return
        
        self.running = True
        self.logger.info("AutomationController: Started")
        
        # Transition from SAFE_IDLE to MONITORING
        if self.state_machine.is_state(SystemState.SAFE_IDLE):
            self.state_machine.transition(SystemState.MONITORING, "Starting automation")
    
    def stop(self):
        """Stop the automation loop."""
        self.running = False
        self.logger.info("AutomationController: Stopped")
    
    def run_cycle(self) -> bool:
        """
        Run one automation cycle.
        
        Returns:
            True if cycle completed successfully, False otherwise
        """
        try:
            current_time = time.time()
            
            # Check if enough time has passed for next cycle
            if current_time - self.last_cycle_time < self.cycle_interval:
                return True
            
            self.last_cycle_time = current_time
            
            # Handle different states
            current_state = self.state_machine.get_state()
            
            if current_state == SystemState.MONITORING:
                return self._handle_monitoring()
            
            elif current_state == SystemState.DECIDING:
                return self._handle_deciding()
            
            elif current_state == SystemState.WATERING:
                return self._handle_watering()
            
            elif current_state == SystemState.SAFE_MODE:
                return self._handle_safe_mode()
            
            elif current_state == SystemState.RECOVERY:
                return self._handle_recovery()
            
            elif current_state == SystemState.SAFE_IDLE:
                # Restart monitoring
                self.state_machine.transition(SystemState.MONITORING, "Resume monitoring")
                return True
            
            return True
        
        except Exception as e:
            self.logger.error(f"AutomationController: Cycle error: {e}", exc_info=True)
            self._enter_safe_mode(f"Cycle error: {e}")
            return False
    
    def _handle_monitoring(self) -> bool:
        """Handle MONITORING state - read sensors."""
        try:
            self.logger.debug("AutomationController: Reading sensors...")
            
            # Read sensors with timeout protection
            sensor_data = self.hal.read_sensors()
            
            # Validate data
            is_valid, reason = self.validator.validate_sensor_reading(sensor_data)
            
            if not is_valid:
                self.logger.warning(f"AutomationController: Invalid sensor data: {reason}")
                raise DataValidationError(reason)
            
            # Check for outliers
            if self.recent_readings and self._is_outlier(sensor_data):
                self.logger.warning("AutomationController: Outlier detected, retrying...")
                time.sleep(1)
                sensor_data = self.hal.read_sensors()
            
            # Store reading
            self.last_sensor_reading = sensor_data
            self._add_to_recent_readings(sensor_data)
            
            self.logger.debug(
                f"AutomationController: Sensors: moisture={sensor_data['moisture']}%, "
                f"temp={sensor_data['temperature']}C, humidity={sensor_data['humidity']}%"
            )
            
            # Transition to deciding
            self.state_machine.transition(SystemState.DECIDING, "Sensors read successfully")
            return True
        
        except Exception as e:
            self.logger.error(f"AutomationController: Sensor read error: {e}")
            self._enter_safe_mode(f"Sensor error: {e}")
            return False
    
    def _handle_deciding(self) -> bool:
        """Handle DECIDING state - make irrigation decision."""
        try:
            if not self.last_sensor_reading:
                raise Exception("No sensor reading available")
            
            self.logger.debug("AutomationController: Making decision...")
            
            # Get decision from hybrid intelligence
            decision = self.decision_engine.decide(self.last_sensor_reading)
            
            self.logger.info(
                f"AutomationController: Decision: {decision['action']} "
                f"({decision['source']}, conf={decision['confidence']:.2f}) - "
                f"{decision['reason']}"
            )
            
            # Act on decision
            if decision['action']:
                # Start watering
                self.watering_duration = decision['duration']
                self._start_watering()
            else:
                # Don't water - return to monitoring
                self.state_machine.transition(SystemState.SAFE_IDLE, "No watering needed")
            
            return True
        
        except Exception as e:
            self.logger.error(f"AutomationController: Decision error: {e}")
            self._enter_safe_mode(f"Decision error: {e}")
            return False
    
    def _handle_watering(self) -> bool:
        """Handle WATERING state - control pump."""
        try:
            current_time = time.time()
            elapsed = current_time - self.watering_start_time
            
            # Check if watering duration exceeded
            if elapsed >= self.watering_duration:
                self.logger.info(
                    f"AutomationController: Watering complete ({elapsed:.1f}s)"
                )
                self._stop_watering()
                return True
            
            # Check for timeout (safety)
            if elapsed >= self.config.max_watering_duration:
                self.logger.warning(
                    f"AutomationController: Max watering duration exceeded! "
                    f"Forcing pump OFF"
                )
                self._stop_watering()
                return True
            
            # Verify pump is still on
            if not self.hal.get_pump_state():
                self.logger.error("AutomationController: Pump unexpectedly OFF!")
                self._enter_safe_mode("Pump state mismatch")
                return False
            
            return True
        
        except Exception as e:
            self.logger.error(f"AutomationController: Watering error: {e}")
            self._stop_watering()
            self._enter_safe_mode(f"Watering error: {e}")
            return False
    
    def _handle_safe_mode(self) -> bool:
        """Handle SAFE_MODE state - error state."""
        # Ensure pump is OFF
        try:
            if self.hal.get_pump_state():
                self.logger.warning("AutomationController: Pump ON in SAFE_MODE, turning OFF")
                self.hal.set_pump(False)
        except Exception as e:
            self.logger.error(f"AutomationController: Failed to turn off pump: {e}")
        
        # Check if should attempt recovery
        if self.state_machine.should_exit_safe_mode():
            self.state_machine.transition(SystemState.RECOVERY, "Attempting recovery")
        
        return True
    
    def _handle_recovery(self) -> bool:
        """Handle RECOVERY state - attempt recovery."""
        try:
            self.logger.info("AutomationController: Attempting recovery...")
            
            # Test sensor reading
            sensor_data = self.hal.read_sensors()
            is_valid, _ = self.validator.validate_sensor_reading(sensor_data)
            
            if not is_valid:
                raise Exception("Sensor validation failed")
            
            # Test pump control
            self.hal.set_pump(False)  # Ensure OFF
            
            # Recovery successful
            self.logger.info("AutomationController: Recovery successful")
            self.state_machine.reset_error_count()
            self.state_machine.transition(SystemState.SAFE_IDLE, "Recovery complete")
            return True
        
        except Exception as e:
            self.logger.error(f"AutomationController: Recovery failed: {e}")
            self.state_machine.transition(SystemState.SAFE_MODE, f"Recovery failed: {e}")
            return False
    
    def _start_watering(self):
        """Start watering operation."""
        try:
            self.logger.info(
                f"AutomationController: Starting watering (duration: {self.watering_duration}s)"
            )
            
            # Turn on pump
            self.hal.set_pump(True)
            
            # Record start time
            self.watering_start_time = time.time()
            
            # Record in decision engine
            self.decision_engine.record_watering()
            
            # Transition state
            self.state_machine.transition(
                SystemState.WATERING,
                f"Watering for {self.watering_duration}s"
            )
        
        except Exception as e:
            self.logger.error(f"AutomationController: Failed to start watering: {e}")
            self._enter_safe_mode(f"Watering start error: {e}")
    
    def _stop_watering(self):
        """Stop watering operation."""
        try:
            # Turn off pump
            self.hal.set_pump(False)
            
            # Calculate actual duration
            if self.watering_start_time:
                actual_duration = time.time() - self.watering_start_time
                self.logger.info(
                    f"AutomationController: Watering stopped (actual: {actual_duration:.1f}s)"
                )
            
            # Reset watering state
            self.watering_start_time = None
            self.watering_duration = 0
            
            # Transition to safe idle
            self.state_machine.transition(SystemState.SAFE_IDLE, "Watering complete")
        
        except Exception as e:
            self.logger.error(f"AutomationController: Failed to stop watering: {e}")
            self._enter_safe_mode(f"Watering stop error: {e}")
    
    def _enter_safe_mode(self, reason: str):
        """
        Enter safe mode (emergency state).
        
        Args:
            reason: Reason for entering safe mode
        """
        try:
            # Ensure pump is OFF
            self.hal.set_pump(False)
        except Exception as e:
            self.logger.critical(f"AutomationController: CRITICAL - Cannot turn off pump: {e}")
        
        # Transition to safe mode
        try:
            self.state_machine.transition(SystemState.SAFE_MODE, reason)
        except Exception as e:
            self.logger.error(f"AutomationController: State transition error: {e}")
            # Force state change
            self.state_machine.current_state = SystemState.SAFE_MODE
    
    def _is_outlier(self, sensor_data: Dict) -> bool:
        """Check if sensor reading is an outlier."""
        if len(self.recent_readings) < 3:
            return False
        
        recent_moisture = [r['moisture'] for r in self.recent_readings]
        return self.validator.is_outlier(sensor_data['moisture'], recent_moisture)
    
    def _add_to_recent_readings(self, sensor_data: Dict):
        """Add reading to recent readings history."""
        self.recent_readings.append(sensor_data)
        if len(self.recent_readings) > self.max_recent_readings:
            self.recent_readings.pop(0)
    
    def get_status(self) -> Dict:
        """Get controller status."""
        return {
            'running': self.running,
            'watering': self.state_machine.is_state(SystemState.WATERING),
            'watering_duration_remaining': (
                self.watering_duration - (time.time() - self.watering_start_time)
                if self.watering_start_time else 0
            ),
            'last_sensor_reading': self.last_sensor_reading,
            'pump_state': self.hal.get_pump_state()
        }
