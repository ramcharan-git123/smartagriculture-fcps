"""
State Machine

Manages system states and transitions for the irrigation system.
Ensures safe state transitions and maintains system integrity.
"""

from enum import Enum
import time
from typing import Optional
from src.utils.errors import StateMachineError


class SystemState(Enum):
    """System states."""
    BOOT = "boot"                    # System starting up
    INITIALIZING = "initializing"    # Loading resources
    SAFE_IDLE = "safe_idle"          # Ready, pump OFF, stable
    MONITORING = "monitoring"        # Reading sensors
    DECIDING = "deciding"            # Running decision logic
    WATERING = "watering"            # Pump ON, irrigating
    SAFE_MODE = "safe_mode"          # Error state, pump OFF
    RECOVERY = "recovery"            # Attempting recovery
    SHUTDOWN = "shutdown"            # Graceful shutdown


class StateMachine:
    """Finite state machine for system control."""
    
    def __init__(self, config, logger):
        """
        Initialize state machine.
        
        Args:
            config: Configuration object
            logger: Logger instance
        """
        self.config = config
        self.logger = logger
        
        self.current_state = SystemState.BOOT
        self.previous_state: Optional[SystemState] = None
        self.state_entry_time = time.time()
        self.error_count = 0
        
        # State transition history (for debugging)
        self.transition_history = []
        self.max_history = 50
    
    def transition(self, new_state: SystemState, reason: str = "") -> None:
        """
        Transition to a new state.
        
        Args:
            new_state: Target state
            reason: Reason for transition
        """
        # Validate transition
        if not self._is_valid_transition(self.current_state, new_state):
            raise StateMachineError(
                f"Invalid transition: {self.current_state.value} -> {new_state.value}"
            )
        
        # Log transition
        self.logger.info(
            f"State: {self.current_state.value} -> {new_state.value} ({reason})"
        )
        
        # Exit current state
        self._exit_state(self.current_state)
        
        # Update state
        self.previous_state = self.current_state
        self.current_state = new_state
        self.state_entry_time = time.time()
        
        # Record transition
        self.transition_history.append({
            'from': self.previous_state.value,
            'to': new_state.value,
            'time': time.time(),
            'reason': reason
        })
        
        # Trim history
        if len(self.transition_history) > self.max_history:
            self.transition_history = self.transition_history[-self.max_history:]
        
        # Enter new state
        self._enter_state(new_state)
    
    def _is_valid_transition(self, from_state: SystemState, to_state: SystemState) -> bool:
        """
        Check if state transition is valid.
        
        Args:
            from_state: Current state
            to_state: Target state
            
        Returns:
            True if transition is valid
        """
        # Define valid transitions
        valid_transitions = {
            SystemState.BOOT: [SystemState.INITIALIZING],
            SystemState.INITIALIZING: [SystemState.SAFE_IDLE, SystemState.SAFE_MODE],
            SystemState.SAFE_IDLE: [SystemState.MONITORING, SystemState.SHUTDOWN, SystemState.SAFE_MODE],
            SystemState.MONITORING: [SystemState.DECIDING, SystemState.SAFE_MODE],
            SystemState.DECIDING: [SystemState.WATERING, SystemState.SAFE_IDLE, SystemState.SAFE_MODE],
            SystemState.WATERING: [SystemState.MONITORING, SystemState.SAFE_IDLE, SystemState.SAFE_MODE],
            SystemState.SAFE_MODE: [SystemState.RECOVERY, SystemState.SHUTDOWN],
            SystemState.RECOVERY: [SystemState.SAFE_IDLE, SystemState.SAFE_MODE],
            SystemState.SHUTDOWN: []  # Terminal state
        }
        
        # Allow transition to SAFE_MODE from any state (emergency)
        if to_state == SystemState.SAFE_MODE:
            return True
        
        # Allow transition to SHUTDOWN from any state (clean exit)
        if to_state == SystemState.SHUTDOWN:
            return True
        
        return to_state in valid_transitions.get(from_state, [])
    
    def _enter_state(self, state: SystemState) -> None:
        """
        Execute actions when entering a state.
        
        Args:
            state: State being entered
        """
        if state == SystemState.SAFE_IDLE:
            self.logger.info("StateMachine: Entered SAFE_IDLE - System ready")
        
        elif state == SystemState.WATERING:
            self.logger.info("StateMachine: Entered WATERING - Pump should be ON")
        
        elif state == SystemState.SAFE_MODE:
            self.error_count += 1
            self.logger.error(f"StateMachine: Entered SAFE_MODE (error #{self.error_count})")
        
        elif state == SystemState.RECOVERY:
            self.logger.info("StateMachine: Entered RECOVERY - Attempting recovery")
    
    def _exit_state(self, state: SystemState) -> None:
        """
        Execute actions when exiting a state.
        
        Args:
            state: State being exited
        """
        if state == SystemState.WATERING:
            self.logger.info("StateMachine: Exiting WATERING - Pump should turn OFF")
    
    def get_state(self) -> SystemState:
        """Get current state."""
        return self.current_state
    
    def is_state(self, state: SystemState) -> bool:
        """
        Check if in specific state.
        
        Args:
            state: State to check
            
        Returns:
            True if in the specified state
        """
        return self.current_state == state
    
    def get_time_in_state(self) -> float:
        """
        Get time elapsed in current state.
        
        Returns:
            Seconds in current state
        """
        return time.time() - self.state_entry_time
    
    def should_exit_safe_mode(self) -> bool:
        """
        Check if system should attempt recovery from safe mode.
        
        Returns:
            True if recovery should be attempted
        """
        if self.current_state != SystemState.SAFE_MODE:
            return False
        
        # Don't attempt recovery too soon
        time_in_state = self.get_time_in_state()
        if time_in_state < self.config.recovery_delay:
            return False
        
        # Don't attempt recovery if too many errors
        if self.error_count >= self.config.max_error_count:
            self.logger.error(
                f"StateMachine: Max error count reached ({self.error_count}). "
                f"Manual intervention required."
            )
            return False
        
        return True
    
    def reset_error_count(self) -> None:
        """Reset error counter (after successful recovery)."""
        old_count = self.error_count
        self.error_count = 0
        self.logger.info(f"StateMachine: Error count reset (was {old_count})")
    
    def get_status(self) -> dict:
        """
        Get state machine status.
        
        Returns:
            Status dictionary
        """
        return {
            'current_state': self.current_state.value,
            'previous_state': self.previous_state.value if self.previous_state else None,
            'time_in_state': round(self.get_time_in_state(), 2),
            'error_count': self.error_count,
            'recent_transitions': self.transition_history[-5:]  # Last 5 transitions
        }
