"""Control modules for state machine and automation."""
