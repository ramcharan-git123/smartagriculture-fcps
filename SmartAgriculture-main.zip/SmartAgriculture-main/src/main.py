"""
Smart Agriculture Node - Main Application

Entry point for the intelligent autonomous irrigation system.
"""

import sys
import time
import signal
import argparse
import logging
from logging.handlers import RotatingFileHandler
from pathlib import Path

# Add src directory to path
sys.path.insert(0, str(Path(__file__).parent.parent))

from src.utils.config import config
from src.utils.errors import SmartAgricultureError
from src.hardware.hal import HardwareAbstractionLayer
from src.intelligence.decision_engine import DecisionEngine
from src.control.state_machine import StateMachine, SystemState
from src.control.automation import AutomationController
from src.data.logger import DataLogger
from src.cloud.dashboard_api import app as dashboard_app, init_dashboard
import threading


class SmartAgricultureSystem:
    """Main system class orchestrating all components."""
    
    def __init__(self):
        """Initialize the system."""
        self.config = config
        self.logger = None
        self.hal = None
        self.decision_engine = None
        self.state_machine = None
        self.automation = None
        self.data_logger = None
        self.dashboard_thread = None
        self.running = False
        
        # Setup signal handlers for graceful shutdown
        signal.signal(signal.SIGINT, self._signal_handler)
        signal.signal(signal.SIGTERM, self._signal_handler)
    
    def _setup_logging(self):
        """Setup logging system."""
        # Create logger
        self.logger = logging.getLogger('SmartAgriculture')
        self.logger.setLevel(getattr(logging, self.config.log_level))
        
        # Console handler
        console_handler = logging.StreamHandler()
        console_handler.setLevel(logging.INFO if not self.config.debug_mode else logging.DEBUG)
        console_format = logging.Formatter(
            '%(asctime)s - %(name)s - %(levelname)s - %(message)s',
            datefmt='%Y-%m-%d %H:%M:%S'
        )
        console_handler.setFormatter(console_format)
        self.logger.addHandler(console_handler)
        
        # File handler (rotating)
        log_file = Path(self.config.log_dir) / 'system.log'
        file_handler = RotatingFileHandler(
            log_file,
            maxBytes=self.config.log_max_size * 1024 * 1024,  # MB to bytes
            backupCount=self.config.log_backup_count
        )
        file_handler.setLevel(logging.DEBUG)
        file_format = logging.Formatter(
            '%(asctime)s - %(name)s - [%(levelname)s] - %(module)s.%(funcName)s:%(lineno)d - %(message)s'
        )
        file_handler.setFormatter(file_format)
        self.logger.addHandler(file_handler)
        
        self.logger.info("=" * 70)
        self.logger.info("Smart Agriculture Node - Intelligent Autonomous Irrigation System")
        self.logger.info("=" * 70)
        self.logger.info(f"System Mode: {self.config.system_mode}")
        self.logger.info(f"Operation Mode: {self.config.operation_mode}")
        self.logger.info(f"Debug Mode: {self.config.debug_mode}")
        self.logger.info(f"ML Enabled: {self.config.ml_enabled}")
        self.logger.info(f"Cloud Enabled: {self.config.cloud_enabled}")
        self.logger.info(f"Dashboard Enabled: {self.config.dashboard_enabled}")
    
    def initialize(self):
        """Initialize all system components."""
        try:
            self.logger.info("Initializing system components...")
            
            # Initialize state machine
            self.logger.info("Initializing state machine...")
            self.state_machine = StateMachine(self.config, self.logger)
            self.state_machine.transition(SystemState.INITIALIZING, "System startup")
            
            # Initialize data logger
            self.logger.info("Initializing data logger...")
            self.data_logger = DataLogger(self.config, self.logger)
            self.data_logger.log_system_event('startup', 'INITIALIZING', 'System starting')
            
            # Initialize hardware abstraction layer
            self.logger.info("Initializing hardware abstraction layer...")
            self.hal = HardwareAbstractionLayer(self.config, self.logger)
            
            # Initialize decision engine
            self.logger.info("Initializing decision engine...")
            self.decision_engine = DecisionEngine(self.config, self.logger)
            
            # Initialize automation controller
            self.logger.info("Initializing automation controller...")
            self.automation = AutomationController(
                self.config, self.logger, self.hal,
                self.decision_engine, self.state_machine
            )
            
            # Start dashboard if enabled
            if self.config.dashboard_enabled:
                self.logger.info(f"Starting dashboard on http://{self.config.dashboard_host}:{self.config.dashboard_port}")
                init_dashboard(self)
                self.dashboard_thread = threading.Thread(
                    target=lambda: dashboard_app.run(
                        host=self.config.dashboard_host,
                        port=self.config.dashboard_port,
                        debug=False,
                        use_reloader=False
                    ),
                    daemon=True
                )
                self.dashboard_thread.start()
                self.logger.info("Dashboard started successfully")
            
            # Transition to safe idle state
            self.state_machine.transition(SystemState.SAFE_IDLE, "Initialization complete")
            self.logger.info("System initialization complete!")
            
            # Log system status
            self._log_system_status()
            
            return True
        
        except Exception as e:
            self.logger.error(f"Initialization failed: {e}", exc_info=True)
            if self.state_machine:
                self.state_machine.transition(SystemState.SAFE_MODE, f"Init error: {e}")
            return False
    
    def run(self):
        """Run the main system loop."""
        if not self.automation:
            self.logger.error("System not initialized!")
            return
        
        self.running = True
        self.automation.start()
        
        self.logger.info("Entering main control loop...")
        self.data_logger.log_system_event('running', 'MONITORING', 'Main loop started')
        
        try:
            while self.running:
                # Run one automation cycle
                success = self.automation.run_cycle()
                
                # Log sensor data if available
                if self.automation.last_sensor_reading:
                    self.data_logger.log_sensor_reading(self.automation.last_sensor_reading)
                
                # Small sleep to prevent CPU spinning
                time.sleep(0.1)
        
        except KeyboardInterrupt:
            self.logger.info("Keyboard interrupt received")
        
        except Exception as e:
            self.logger.error(f"Main loop error: {e}", exc_info=True)
        
        finally:
            self.shutdown()
    
    def shutdown(self):
        """Gracefully shutdown the system."""
        self.logger.info("Shutting down system...")
        self.data_logger.log_system_event('shutdown', self.state_machine.get_state().value, 
                                         'System shutdown initiated')
        
        self.running = False
        
        # Stop automation
        if self.automation:
            self.automation.stop()
        
        # Transition to shutdown state
        if self.state_machine:
            try:
                if self.state_machine.get_state() != SystemState.SHUTDOWN:
                    self.state_machine.transition(SystemState.SHUTDOWN, "User initiated")
            except Exception as e:
                self.logger.error(f"Error during state transition: {e}")
        
        # Cleanup hardware
        if self.hal:
            self.logger.info("Cleaning up hardware...")
            self.hal.cleanup()
        
        self.logger.info("Shutdown complete. Goodbye!")
        self.logger.info("=" * 70)
    
    def _signal_handler(self, signum, frame):
        """Handle shutdown signals."""
        signal_names = {
            signal.SIGINT: 'SIGINT',
            signal.SIGTERM: 'SIGTERM'
        }
        signal_name = signal_names.get(signum, f'Signal {signum}')
        self.logger.info(f"Received {signal_name}, initiating shutdown...")
        self.running = False
    
    def _log_system_status(self):
        """Log current system status."""
        self.logger.info("System Status:")
        self.logger.info(f"  State Machine: {self.state_machine.get_state().value}")
        self.logger.info(f"  Decision Engine: ML={self.decision_engine.ml_advisor.is_enabled()}")
        
        # Test sensor reading
        try:
            test_reading = self.hal.read_sensors()
            self.logger.info(f"  Sensors: OK (moisture={test_reading['moisture']}%, "
                           f"temp={test_reading['temperature']}C)")
        except Exception as e:
            self.logger.warning(f"  Sensors: Error - {e}")


def parse_arguments():
    """Parse command line arguments."""
    parser = argparse.ArgumentParser(
        description='Smart Agriculture Node - Intelligent Autonomous Irrigation System'
    )
    
    parser.add_argument(
        '--mode',
        choices=['simulation', 'hardware'],
        help='System mode (overrides config)'
    )
    
    parser.add_argument(
        '--operation',
        choices=['auto', 'manual'],
        help='Operation mode (overrides config)'
    )
    
    parser.add_argument(
        '--debug',
        action='store_true',
        help='Enable debug mode'
    )
    
    parser.add_argument(
        '--no-ml',
        action='store_true',
        help='Disable ML advisory layer'
    )
    
    parser.add_argument(
        '--test',
        action='store_true',
        help='Run in test mode (single cycle then exit)'
    )
    
    return parser.parse_args()


def main():
    """Main entry point."""
    # Parse command line arguments
    args = parse_arguments()
    
    # Override config with command line arguments
    if args.mode:
        import os
        os.environ['SYSTEM_MODE'] = args.mode
    
    if args.operation:
        import os
        os.environ['OPERATION_MODE'] = args.operation
    
    if args.debug:
        import os
        os.environ['DEBUG_MODE'] = 'true'
        os.environ['LOG_LEVEL'] = 'DEBUG'
    
    if args.no_ml:
        import os
        os.environ['ML_ENABLED'] = 'false'
    
    # Create and initialize system
    system = SmartAgricultureSystem()
    system._setup_logging()
    
    # Initialize components
    if not system.initialize():
        system.logger.error("Failed to initialize system. Exiting.")
        sys.exit(1)
    
    # Run system
    if args.test:
        # Test mode - run single cycle
        system.logger.info("Running in test mode (single cycle)...")
        system.automation.start()
        
        for i in range(3):  # Run 3 cycles for testing
            system.logger.info(f"Test cycle {i+1}/3")
            system.automation.run_cycle()
            time.sleep(2)
        
        system.logger.info("Test complete!")
        system.shutdown()
    else:
        # Normal mode - run continuously
        system.run()


if __name__ == '__main__':
    main()
