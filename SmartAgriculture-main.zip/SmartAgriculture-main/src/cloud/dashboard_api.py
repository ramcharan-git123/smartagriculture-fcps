"""
Dashboard API

Lightweight Flask API for web dashboard.
"""

from flask import Flask, jsonify, request
from flask_cors import CORS
import sys
from pathlib import Path

# Add src to path
sys.path.insert(0, str(Path(__file__).parent.parent))

from src.utils.config import config
from src.data.logger import DataLogger
import logging


# Create Flask app
app = Flask(__name__)
CORS(app)

# Global references (will be set by main system)
system_ref = None
logger = logging.getLogger('dashboard')


def init_dashboard(system):
    """
    Initialize dashboard with system reference.
    
    Args:
        system: Main system instance
    """
    global system_ref
    system_ref = system


@app.route('/')
def index():
    """Serve dashboard HTML."""
    return """
    <!DOCTYPE html>
    <html>
    <head>
        <title>Smart Agriculture IoT Dashboard</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <style>
            * { margin: 0; padding: 0; box-sizing: border-box; }
            body { 
                font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; 
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                min-height: 100vh;
                padding: 20px;
            }
            .container { max-width: 1400px; margin: 0 auto; }
            
            .header {
                background: white;
                padding: 30px;
                border-radius: 15px;
                box-shadow: 0 10px 30px rgba(0,0,0,0.2);
                margin-bottom: 30px;
                text-align: center;
            }
            .header h1 { 
                font-size: 2.5em; 
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                -webkit-background-clip: text;
                -webkit-text-fill-color: transparent;
                margin-bottom: 10px;
            }
            .header p { color: #666; font-size: 1.1em; }
            
            .grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 20px; }
            
            .card { 
                background: white; 
                padding: 25px; 
                border-radius: 15px; 
                box-shadow: 0 10px 30px rgba(0,0,0,0.2);
                transition: transform 0.3s ease, box-shadow 0.3s ease;
            }
            .card:hover { 
                transform: translateY(-5px); 
                box-shadow: 0 15px 40px rgba(0,0,0,0.3);
            }
            
            .card h2 { 
                font-size: 1.3em; 
                margin-bottom: 20px; 
                color: #333;
                border-bottom: 3px solid #667eea;
                padding-bottom: 10px;
            }
            
            .metric-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 20px; }
            
            .metric { 
                text-align: center; 
                padding: 20px;
                background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
                border-radius: 10px;
            }
            .metric h3 { 
                font-size: 0.9em; 
                color: #666; 
                margin-bottom: 10px;
                text-transform: uppercase;
                letter-spacing: 1px;
            }
            .metric .value { 
                font-size: 2.5em; 
                font-weight: bold; 
                color: #667eea;
                display: block;
                margin: 10px 0;
            }
            .metric .unit { 
                font-size: 1em; 
                color: #999;
            }
            
            .status-badge {
                display: inline-block;
                padding: 10px 25px;
                border-radius: 25px;
                font-weight: bold;
                font-size: 1.1em;
                text-transform: uppercase;
                letter-spacing: 1px;
            }
            .status-safe { background: linear-gradient(135deg, #11998e 0%, #38ef7d 100%); color: white; }
            .status-watering { background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%); color: white; }
            .status-monitoring { background: linear-gradient(135deg, #fa709a 0%, #fee140 100%); color: white; }
            .status-deciding { background: linear-gradient(135deg, #a8edea 0%, #fed6e3 100%); color: #333; }
            
            .pump-status {
                text-align: center;
                padding: 30px;
                font-size: 2em;
                font-weight: bold;
            }
            .pump-on { 
                color: #38ef7d;
                text-shadow: 0 0 20px rgba(56, 239, 125, 0.5);
                animation: pulse 2s infinite;
            }
            .pump-off { color: #ccc; }
            
            @keyframes pulse {
                0%, 100% { opacity: 1; }
                50% { opacity: 0.6; }
            }
            
            .stats-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 15px; }
            .stat-item {
                background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
                padding: 15px;
                border-radius: 10px;
            }
            .stat-item strong { 
                display: block; 
                color: #667eea; 
                font-size: 1.8em;
                margin-bottom: 5px;
            }
            .stat-item span { color: #666; font-size: 0.9em; }
            
            .last-update { 
                font-size: 0.85em; 
                color: #999; 
                margin-top: 15px;
                text-align: center;
                font-style: italic;
            }
            
            .loading {
                text-align: center;
                padding: 20px;
                color: #999;
                font-style: italic;
            }
            
            @media (max-width: 768px) {
                .metric-grid { grid-template-columns: 1fr; }
                .stats-grid { grid-template-columns: 1fr; }
            }
        </style>
    </head>
    <body>
        <div class="container">
            <div class="header">
                <h1>🌱 Smart Agriculture IoT System</h1>
                <p>Real-time Intelligent Irrigation Monitoring & Control</p>
            </div>
            
            <div class="grid">
                <div class="card">
                    <h2>⚡ System Status</h2>
                    <div id="system-status" style="text-align: center; padding: 20px;">
                        <div class="loading">Connecting...</div>
                    </div>
                </div>
                
                <div class="card">
                    <h2>💧 Pump Control</h2>
                    <div class="pump-status" id="pump-status">--</div>
                </div>
            </div>
            
            <div class="card" style="margin-top: 20px;">
                <h2>📊 Live Sensor Readings</h2>
                <div class="metric-grid">
                    <div class="metric">
                        <h3>💧 Soil Moisture</h3>
                        <span class="value" id="moisture">--</span>
                        <span class="unit">%</span>
                    </div>
                    <div class="metric">
                        <h3>🌡️ Temperature</h3>
                        <span class="value" id="temperature">--</span>
                        <span class="unit">°C</span>
                    </div>
                    <div class="metric">
                        <h3>💨 Humidity</h3>
                        <span class="value" id="humidity">--</span>
                        <span class="unit">%</span>
                    </div>
                </div>
                <p class="last-update" id="last-reading">Waiting for data...</p>
            </div>
            
            <div class="card" style="margin-top: 20px;">
                <h2>📈 System Statistics</h2>
                <div class="stats-grid" id="statistics">
                    <div class="loading">Loading statistics...</div>
                </div>
            </div>
        </div>
        
        <script>
            function updateDashboard() {
                fetch('/api/status')
                    .then(response => response.json())
                    .then(data => {
                        // System status - determine badge style based on state
                        const stateMap = {
                            'safe_idle': 'status-safe',
                            'watering': 'status-watering',
                            'monitoring': 'status-monitoring',
                            'deciding': 'status-deciding'
                        };
                        const stateClass = stateMap[data.state] || 'status-safe';
                        document.getElementById('system-status').innerHTML = 
                            `<span class="status-badge ${stateClass}">${data.state.replace('_', ' ')}</span>`;
                        
                        // Sensor readings
                        if (data.last_reading) {
                            document.getElementById('moisture').textContent = 
                                data.last_reading.moisture.toFixed(1);
                            document.getElementById('temperature').textContent = 
                                data.last_reading.temperature.toFixed(1);
                            document.getElementById('humidity').textContent = 
                                data.last_reading.humidity.toFixed(1);
                            document.getElementById('last-reading').textContent = 
                                `Last update: ${new Date(data.last_reading.timestamp * 1000).toLocaleString()}`;
                        }
                        
                        // Pump status
                        const pumpClass = data.pump_state ? 'pump-on' : 'pump-off';
                        const pumpText = data.pump_state ? '💧 PUMP ON' : '⭕ PUMP OFF';
                        document.getElementById('pump-status').innerHTML = 
                            `<span class="${pumpClass}">${pumpText}</span>`;
                        
                        // Statistics
                        document.getElementById('statistics').innerHTML = 
                            `<div class="stat-item">
                                <strong>${data.statistics.total_readings || 0}</strong>
                                <span>Total Sensor Readings</span>
                            </div>
                            <div class="stat-item">
                                <strong>${data.statistics.total_waterings || 0}</strong>
                                <span>Irrigation Events</span>
                            </div>
                            <div class="stat-item">
                                <strong>${(data.statistics.avg_moisture || 0).toFixed(1)}%</strong>
                                <span>Average Moisture</span>
                            </div>
                            <div class="stat-item">
                                <strong>${(data.statistics.avg_temperature || 0).toFixed(1)}°C</strong>
                                <span>Average Temperature</span>
                            </div>`;
                    })
                    .catch(error => {
                        console.error('Error:', error);
                        document.getElementById('system-status').innerHTML = 
                            '<span class="status-badge" style="background: #f44336; color: white;">CONNECTION ERROR</span>';
                    });
            }
            
            // Update every 3 seconds
            updateDashboard();
            setInterval(updateDashboard, 3000);
        </script>
    </body>
    </html>
    """


@app.route('/api/status')
def api_status():
    """Get system status."""
    if not system_ref:
        return jsonify({'error': 'System not initialized'}), 503
    
    try:
        # Get automation status
        automation_status = system_ref.automation.get_status()
        
        # Get statistics
        stats = system_ref.data_logger.get_statistics()
        
        return jsonify({
            'state': system_ref.state_machine.get_state().value,
            'running': automation_status['running'],
            'watering': automation_status['watering'],
            'pump_state': automation_status['pump_state'],
            'last_reading': automation_status['last_sensor_reading'],
            'statistics': stats
        })
    
    except Exception as e:
        logger.error(f"Dashboard API error: {e}")
        return jsonify({'error': str(e)}), 500


@app.route('/api/sensors')
def api_sensors():
    """Get latest sensor readings."""
    if not system_ref:
        return jsonify({'error': 'System not initialized'}), 503
    
    try:
        recent = system_ref.data_logger.get_recent_readings(count=100)
        return jsonify(recent)
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/api/events')
def api_events():
    """Get recent irrigation events."""
    if not system_ref:
        return jsonify({'error': 'System not initialized'}), 503
    
    try:
        events = system_ref.data_logger.get_recent_events(count=50)
        return jsonify(events)
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500


def run_dashboard(host='0.0.0.0', port=5000):
    """
    Run dashboard server.
    
    Args:
        host: Host address
        port: Port number
    """
    logger.info(f"Starting dashboard on http://{host}:{port}")
    app.run(host=host, port=port, debug=False)
