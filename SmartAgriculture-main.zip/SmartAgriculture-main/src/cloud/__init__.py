"""Cloud communication modules."""
