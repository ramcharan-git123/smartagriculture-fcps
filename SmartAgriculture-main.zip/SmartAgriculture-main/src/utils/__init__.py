"""Utility modules for configuration, validation, and error handling."""
