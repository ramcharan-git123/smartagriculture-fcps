"""
Configuration Management Module

Loads configuration from environment variables and YAML files.
Provides centralized access to all system configuration.
"""

import os
from typing import Any, Dict
from pathlib import Path
from dotenv import load_dotenv
import yaml


class Config:
    """Configuration manager for the Smart Agriculture System."""
    
    def __init__(self):
        """Initialize configuration from environment and files."""
        # Initialize yaml_config first
        self.yaml_config = {}
        
        # Load environment variables from .env file
        env_path = Path(__file__).parent.parent.parent / '.env'
        if env_path.exists():
            load_dotenv(env_path)
        
        # Load YAML configuration if exists
        self.yaml_config = self._load_yaml_config()
    
    def _load_yaml_config(self) -> Dict[str, Any]:
        """Load configuration from YAML file based on mode."""
        config_dir = Path(__file__).parent.parent.parent / 'config'
        
        # Determine which config file to load
        mode = self.get('SYSTEM_MODE', 'simulation')
        config_file = config_dir / f'{mode}.yaml'
        
        if not config_file.exists():
            config_file = config_dir / 'default.yaml'
        
        if config_file.exists():
            with open(config_file, 'r') as f:
                return yaml.safe_load(f) or {}
        
        return {}
    
    def get(self, key: str, default: Any = None) -> Any:
        """
        Get configuration value by key.
        
        Priority: Environment variable > YAML config > Default
        
        Args:
            key: Configuration key
            default: Default value if key not found
            
        Returns:
            Configuration value
        """
        # Check environment variable first
        env_value = os.getenv(key)
        if env_value is not None:
            return self._convert_type(env_value)
        
        # Check YAML config
        yaml_value = self.yaml_config.get(key)
        if yaml_value is not None:
            return yaml_value
        
        return default
    
    def _convert_type(self, value: str) -> Any:
        """Convert string environment variable to appropriate type."""
        # Boolean conversion
        if value.lower() in ('true', 'yes', '1', 'on'):
            return True
        if value.lower() in ('false', 'no', '0', 'off'):
            return False
        
        # Try numeric conversion
        try:
            if '.' in value:
                return float(value)
            return int(value)
        except ValueError:
            pass
        
        return value
    
    # System configuration properties
    @property
    def system_mode(self) -> str:
        """Get system mode: 'simulation' or 'hardware'."""
        return self.get('SYSTEM_MODE', 'simulation')
    
    @property
    def operation_mode(self) -> str:
        """Get operation mode: 'auto' or 'manual'."""
        return self.get('OPERATION_MODE', 'auto')
    
    @property
    def debug_mode(self) -> bool:
        """Get debug mode flag."""
        return self.get('DEBUG_MODE', False)
    
    # GPIO configuration
    @property
    def gpio_soil_moisture(self) -> int:
        """GPIO pin for soil moisture sensor."""
        return self.get('GPIO_SOIL_MOISTURE', 17)
    
    @property
    def gpio_dht_sensor(self) -> int:
        """GPIO pin for DHT temperature/humidity sensor."""
        return self.get('GPIO_DHT_SENSOR', 4)
    
    @property
    def gpio_relay_pump(self) -> int:
        """GPIO pin for pump relay."""
        return self.get('GPIO_RELAY_PUMP', 27)
    
    @property
    def gpio_status_led(self) -> int:
        """GPIO pin for status LED."""
        return self.get('GPIO_STATUS_LED', 22)
    
    # Sensor thresholds
    @property
    def critical_low_moisture(self) -> float:
        """Critical low moisture threshold (%)."""
        return self.get('CRITICAL_LOW_MOISTURE', 20)
    
    @property
    def critical_high_moisture(self) -> float:
        """Critical high moisture threshold (%)."""
        return self.get('CRITICAL_HIGH_MOISTURE', 80)
    
    @property
    def optimal_low_moisture(self) -> float:
        """Optimal low moisture threshold (%)."""
        return self.get('OPTIMAL_LOW_MOISTURE', 30)
    
    @property
    def optimal_high_moisture(self) -> float:
        """Optimal high moisture threshold (%)."""
        return self.get('OPTIMAL_HIGH_MOISTURE', 70)
    
    @property
    def max_safe_temp(self) -> float:
        """Maximum safe temperature (°C)."""
        return self.get('MAX_SAFE_TEMP', 45)
    
    @property
    def min_safe_temp(self) -> float:
        """Minimum safe temperature (°C)."""
        return self.get('MIN_SAFE_TEMP', -5)
    
    # Control configuration
    @property
    def default_watering_duration(self) -> int:
        """Default watering duration (seconds)."""
        return self.get('DEFAULT_WATERING_DURATION', 60)
    
    @property
    def max_watering_duration(self) -> int:
        """Maximum watering duration (seconds)."""
        return self.get('MAX_WATERING_DURATION', 120)
    
    @property
    def min_watering_interval(self) -> int:
        """Minimum interval between watering (seconds)."""
        return self.get('MIN_WATERING_INTERVAL', 300)
    
    @property
    def sensor_read_interval(self) -> int:
        """Sensor read interval (seconds)."""
        return self.get('SENSOR_READ_INTERVAL', 5)
    
    @property
    def sensor_read_timeout(self) -> int:
        """Sensor read timeout (seconds)."""
        return self.get('SENSOR_READ_TIMEOUT', 5)
    
    # ML configuration
    @property
    def ml_enabled(self) -> bool:
        """ML advisory layer enabled flag."""
        return self.get('ML_ENABLED', True)
    
    @property
    def ml_model_path(self) -> str:
        """Path to ML model file."""
        base_path = Path(__file__).parent.parent.parent
        return str(base_path / self.get('ML_MODEL_PATH', 'ml_models/irrigation_model.pkl'))
    
    @property
    def ml_confidence_threshold(self) -> float:
        """ML confidence threshold."""
        return self.get('ML_CONFIDENCE_THRESHOLD', 0.7)
    
    # Cloud configuration
    @property
    def cloud_enabled(self) -> bool:
        """Cloud sync enabled flag."""
        return self.get('CLOUD_ENABLED', False)
    
    @property
    def cloud_provider(self) -> str:
        """Cloud provider: firebase, thingspeak, aws_iot, none."""
        return self.get('CLOUD_PROVIDER', 'none')
    
    @property
    def cloud_sync_interval(self) -> int:
        """Cloud sync interval (seconds)."""
        return self.get('CLOUD_SYNC_INTERVAL', 30)
    
    # Dashboard configuration
    @property
    def dashboard_enabled(self) -> bool:
        """Dashboard enabled flag."""
        return self.get('DASHBOARD_ENABLED', True)
    
    @property
    def dashboard_host(self) -> str:
        """Dashboard web server host."""
        return self.get('DASHBOARD_HOST', '0.0.0.0')
    
    @property
    def dashboard_port(self) -> int:
        """Dashboard web server port."""
        return self.get('DASHBOARD_PORT', 5000)
    
    @property
    def dashboard_api_key(self) -> str:
        """Dashboard API key for authentication."""
        return self.get('DASHBOARD_API_KEY', 'change_this_to_secure_key')
    
    # Storage configuration
    @property
    def database_path(self) -> str:
        """Database file path."""
        base_path = Path(__file__).parent.parent.parent
        db_path = base_path / self.get('DATABASE_PATH', 'data/sensor_data.db')
        db_path.parent.mkdir(parents=True, exist_ok=True)
        return str(db_path)
    
    @property
    def log_dir(self) -> str:
        """Log directory path."""
        base_path = Path(__file__).parent.parent.parent
        log_dir = base_path / self.get('LOG_DIR', 'logs')
        log_dir.mkdir(parents=True, exist_ok=True)
        return str(log_dir)
    
    @property
    def log_level(self) -> str:
        """Log level."""
        return self.get('LOG_LEVEL', 'INFO')
    
    @property
    def log_max_size(self) -> int:
        """Log file max size (MB)."""
        return self.get('LOG_MAX_SIZE', 5)
    
    @property
    def log_backup_count(self) -> int:
        """Number of log backup files."""
        return self.get('LOG_BACKUP_COUNT', 10)
    
    # Safety configuration
    @property
    def max_error_count(self) -> int:
        """Maximum consecutive errors before safe mode."""
        return self.get('MAX_ERROR_COUNT', 5)
    
    @property
    def recovery_delay(self) -> int:
        """Recovery attempt delay (seconds)."""
        return self.get('RECOVERY_DELAY', 60)
    
    @property
    def fail_safe_enabled(self) -> bool:
        """Fail-safe mode enabled flag."""
        return self.get('FAIL_SAFE_ENABLED', True)
    
    # Simulation configuration
    @property
    def sim_initial_moisture(self) -> float:
        """Simulation initial moisture (%)."""
        return self.get('SIM_INITIAL_MOISTURE', 50)
    
    @property
    def sim_initial_temperature(self) -> float:
        """Simulation initial temperature (°C)."""
        return self.get('SIM_INITIAL_TEMPERATURE', 25)
    
    @property
    def sim_initial_humidity(self) -> float:
        """Simulation initial humidity (%)."""
        return self.get('SIM_INITIAL_HUMIDITY', 60)
    
    @property
    def sim_moisture_decrease_rate(self) -> float:
        """Simulation moisture decrease rate per cycle (%)."""
        return self.get('SIM_MOISTURE_DECREASE_RATE', 0.5)
    
    @property
    def sim_moisture_increase_rate(self) -> float:
        """Simulation moisture increase rate when watering (%)."""
        return self.get('SIM_MOISTURE_INCREASE_RATE', 5)
    
    @property
    def sim_add_noise(self) -> bool:
        """Add noise to simulation data."""
        return self.get('SIM_ADD_NOISE', True)
    
    @property
    def sim_noise_level(self) -> float:
        """Simulation noise level."""
        return self.get('SIM_NOISE_LEVEL', 2)
    
    @property
    def device_id(self) -> str:
        """Device identifier."""
        return self.get('DEVICE_ID', 'node_01')
    
    def __repr__(self) -> str:
        """String representation of config."""
        return f"Config(mode={self.system_mode}, operation={self.operation_mode})"


# Global configuration instance
config = Config()
