"""
Data Validation Module

Validates sensor readings and ensures data quality.
"""

from typing import Dict, Tuple
from src.utils.errors import DataValidationError


class DataValidator:
    """Validator for sensor data."""
    
    def __init__(self, config):
        """
        Initialize validator with configuration.
        
        Args:
            config: Configuration object
        """
        self.config = config
    
    def validate_moisture(self, value: float) -> Tuple[bool, str]:
        """
        Validate soil moisture reading.
        
        Args:
            value: Moisture percentage (0-100)
            
        Returns:
            Tuple of (is_valid, reason)
        """
        if not isinstance(value, (int, float)):
            return False, f"Invalid type: {type(value)}"
        
        if value < 0 or value > 100:
            return False, f"Out of range: {value}% (expected 0-100)"
        
        return True, "OK"
    
    def validate_temperature(self, value: float) -> Tuple[bool, str]:
        """
        Validate temperature reading.
        
        Args:
            value: Temperature in Celsius
            
        Returns:
            Tuple of (is_valid, reason)
        """
        if not isinstance(value, (int, float)):
            return False, f"Invalid type: {type(value)}"
        
        min_temp = self.config.min_safe_temp - 10  # Allow some margin
        max_temp = self.config.max_safe_temp + 10
        
        if value < min_temp or value > max_temp:
            return False, f"Out of range: {value}C (expected {min_temp}-{max_temp})"
        
        return True, "OK"
    
    def validate_humidity(self, value: float) -> Tuple[bool, str]:
        """
        Validate humidity reading.
        
        Args:
            value: Humidity percentage (0-100)
            
        Returns:
            Tuple of (is_valid, reason)
        """
        if not isinstance(value, (int, float)):
            return False, f"Invalid type: {type(value)}"
        
        if value < 0 or value > 100:
            return False, f"Out of range: {value}% (expected 0-100)"
        
        return True, "OK"
    
    def validate_sensor_reading(self, reading: Dict) -> Tuple[bool, str]:
        """
        Validate complete sensor reading.
        
        Args:
            reading: Dictionary with 'moisture', 'temperature', 'humidity'
            
        Returns:
            Tuple of (is_valid, reason)
        """
        # Check required fields
        required_fields = ['moisture', 'temperature', 'humidity']
        for field in required_fields:
            if field not in reading:
                return False, f"Missing field: {field}"
        
        # Validate each field
        moisture_valid, moisture_reason = self.validate_moisture(reading['moisture'])
        if not moisture_valid:
            return False, f"Moisture validation failed: {moisture_reason}"
        
        temp_valid, temp_reason = self.validate_temperature(reading['temperature'])
        if not temp_valid:
            return False, f"Temperature validation failed: {temp_reason}"
        
        humidity_valid, humidity_reason = self.validate_humidity(reading['humidity'])
        if not humidity_valid:
            return False, f"Humidity validation failed: {humidity_reason}"
        
        return True, "All validations passed"
    
    def is_outlier(self, current_value: float, recent_values: list, threshold: float = 3.0) -> bool:
        """
        Detect if current value is an outlier compared to recent values.
        
        Args:
            current_value: Current sensor value
            recent_values: List of recent values
            threshold: Number of standard deviations to consider outlier
            
        Returns:
            True if value is an outlier
        """
        if not recent_values or len(recent_values) < 3:
            return False
        
        import statistics
        
        try:
            mean = statistics.mean(recent_values)
            stdev = statistics.stdev(recent_values)
            
            if stdev == 0:
                return False
            
            z_score = abs((current_value - mean) / stdev)
            return z_score > threshold
        except Exception:
            return False
