"""
Custom Exception Classes

Defines specific exceptions for different error types in the system.
"""


class SmartAgricultureError(Exception):
    """Base exception for Smart Agriculture system errors."""
    pass


class HardwareError(SmartAgricultureError):
    """Exception raised for hardware-related errors."""
    pass


class SensorError(HardwareError):
    """Exception raised for sensor read failures."""
    pass


class ActuatorError(HardwareError):
    """Exception raised for actuator control failures."""
    pass


class ConfigurationError(SmartAgricultureError):
    """Exception raised for configuration errors."""
    pass


class DataValidationError(SmartAgricultureError):
    """Exception raised for invalid sensor data."""
    pass


class DecisionEngineError(SmartAgricultureError):
    """Exception raised for decision engine failures."""
    pass


class MLModelError(SmartAgricultureError):
    """Exception raised for ML model errors."""
    pass


class CloudCommunicationError(SmartAgricultureError):
    """Exception raised for cloud connectivity issues."""
    pass


class StorageError(SmartAgricultureError):
    """Exception raised for data storage errors."""
    pass


class StateMachineError(SmartAgricultureError):
    """Exception raised for state machine errors."""
    pass


class SafetyViolationError(SmartAgricultureError):
    """Exception raised for safety constraint violations."""
    pass
