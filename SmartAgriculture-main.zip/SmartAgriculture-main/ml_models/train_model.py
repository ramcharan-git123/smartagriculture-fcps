"""
ML Model Training Script

Trains a machine learning model for irrigation optimization
using historical sensor data.
"""

import sys
import pandas as pd
import numpy as np
from pathlib import Path
from datetime import datetime
import joblib

# Add src directory to path
sys.path.insert(0, str(Path(__file__).parent / 'src'))

from sklearn.ensemble import RandomForestClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.metrics import classification_report, confusion_matrix, accuracy_score


def generate_training_data(num_samples=5000):
    """
    Generate synthetic training data for irrigation model.
    
    In production, this would load real historical data from the database.
    
    Returns:
        DataFrame with training data
    """
    print(f"Generating {num_samples} training samples...")
    
    np.random.seed(42)
    
    data = []
    
    for _ in range(num_samples):
        # Generate sensor readings
        moisture = np.random.uniform(0, 100)
        temperature = np.random.uniform(10, 40)
        humidity = np.random.uniform(20, 90)
        hour = np.random.randint(0, 24)
        day_of_week = np.random.randint(0, 7)
        recent_watering_count = np.random.randint(0, 5)
        
        # Generate target based on rules (with some noise for ML to learn patterns)
        should_water = 0
        
        # Rule-based baseline with some pattern variations
        if moisture < 30:  # Low moisture -> water
            should_water = 1
        elif moisture < 50:  # Medium-low moisture
            # Water more likely in morning (6-10 AM) and evening (6-8 PM)
            if hour in range(6, 11) or hour in range(18, 21):
                should_water = 1 if np.random.random() > 0.3 else 0
            else:
                should_water = 1 if np.random.random() > 0.7 else 0
        elif moisture < 60:  # Medium moisture
            # Rarely water, only in hot dry conditions
            if temperature > 35 and humidity < 30:
                should_water = 1 if np.random.random() > 0.5 else 0
            else:
                should_water = 0
        else:  # High moisture -> don't water
            should_water = 0
        
        # Don't water if recently watered
        if recent_watering_count > 2:
            should_water = 0
        
        # Don't water at night (11 PM - 5 AM)
        if hour >= 23 or hour <= 5:
            should_water = 0
        
        data.append({
            'moisture': moisture,
            'temperature': temperature,
            'humidity': humidity,
            'hour': hour,
            'day_of_week': day_of_week,
            'recent_watering_count': recent_watering_count,
            'should_water': should_water
        })
    
    df = pd.DataFrame(data)
    return df


def train_model(data, model_type='random_forest'):
    """
    Train irrigation prediction model.
    
    Args:
        data: Training data DataFrame
        model_type: 'random_forest' or 'decision_tree'
        
    Returns:
        Trained model
    """
    print(f"\nTraining {model_type} model...")
    
    # Prepare features and target
    X = data[['moisture', 'temperature', 'humidity', 'hour', 'day_of_week', 'recent_watering_count']]
    y = data['should_water']
    
    # Split data
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )
    
    print(f"Training set: {len(X_train)} samples")
    print(f"Test set: {len(X_test)} samples")
    print(f"Class distribution: {y.value_counts().to_dict()}")
    
    # Create model
    if model_type == 'random_forest':
        model = RandomForestClassifier(
            n_estimators=100,
            max_depth=10,
            min_samples_split=10,
            min_samples_leaf=5,
            random_state=42,
            n_jobs=-1
        )
    else:  # decision_tree
        model = DecisionTreeClassifier(
            max_depth=10,
            min_samples_split=10,
            min_samples_leaf=5,
            random_state=42
        )
    
    # Train model
    print("Training...")
    model.fit(X_train, y_train)
    
    # Evaluate
    print("\nModel Evaluation:")
    
    # Training accuracy
    train_pred = model.predict(X_train)
    train_accuracy = accuracy_score(y_train, train_pred)
    print(f"Training Accuracy: {train_accuracy:.4f}")
    
    # Test accuracy
    test_pred = model.predict(X_test)
    test_accuracy = accuracy_score(y_test, test_pred)
    print(f"Test Accuracy: {test_accuracy:.4f}")
    
    # Cross-validation
    cv_scores = cross_val_score(model, X, y, cv=5)
    print(f"Cross-Validation Accuracy: {cv_scores.mean():.4f} (+/- {cv_scores.std():.4f})")
    
    # Classification report
    print("\nClassification Report:")
    print(classification_report(y_test, test_pred, target_names=['No Water', 'Water']))
    
    # Confusion matrix
    print("\nConfusion Matrix:")
    cm = confusion_matrix(y_test, test_pred)
    print(cm)
    print("(TN, FP)")
    print("(FN, TP)")
    
    # Feature importance
    if hasattr(model, 'feature_importances_'):
        print("\nFeature Importance:")
        for feature, importance in zip(X.columns, model.feature_importances_):
            print(f"  {feature}: {importance:.4f}")
    
    return model


def save_model(model, path='ml_models/irrigation_model.pkl'):
    """
    Save trained model to file.
    
    Args:
        model: Trained model
        path: Save path
    """
    # Create directory if needed
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    
    # Save model
    joblib.dump(model, path)
    print(f"\nModel saved to: {path}")
    
    # Save metadata
    metadata = {
        'model_type': type(model).__name__,
        'training_date': datetime.now().isoformat(),
        'features': ['moisture', 'temperature', 'humidity', 'hour', 'day_of_week', 'recent_watering_count'],
        'target': 'should_water'
    }
    
    metadata_path = path.replace('.pkl', '_metadata.txt')
    with open(metadata_path, 'w') as f:
        for key, value in metadata.items():
            f.write(f"{key}: {value}\n")
    
    print(f"Metadata saved to: {metadata_path}")


def main():
    """Main training function."""
    print("=" * 60)
    print("Smart Agriculture - ML Model Training")
    print("=" * 60)
    print()
    
    # Generate training data
    # In production, load from database:
    # data = load_from_database()
    data = generate_training_data(num_samples=5000)
    
    # Save training data for reference
    data_path = 'ml_models/training_data.csv'
    Path(data_path).parent.mkdir(parents=True, exist_ok=True)
    data.to_csv(data_path, index=False)
    print(f"Training data saved to: {data_path}")
    
    # Train model
    model = train_model(data, model_type='random_forest')
    
    # Save model
    save_model(model)
    
    print("\n" + "=" * 60)
    print("Training Complete!")
    print("=" * 60)
    print("\nThe model is ready to use in the irrigation system.")
    print("It will provide irrigation recommendations based on:")
    print("  - Soil moisture")
    print("  - Temperature")
    print("  - Humidity")
    print("  - Time of day")
    print("  - Day of week")
    print("  - Recent watering history")
    print()


if __name__ == '__main__':
    main()
